# 데이터마이닝 감성분석·시각화 제출용 정리본

## 1. 프로젝트 개요

본 폴더는 음식점 리뷰 프로젝트의 후반부 산출물 중 제출·검토에 필요한 파일만 정리한 것입니다.  
High Trust 리뷰를 대상으로 음식점 도메인 감성사전과 문맥 보정 규칙을 적용하여 텍스트 기반 감성별점(`sentiment_star`)을 산출하고, 플랫폼별·식당별·aspect별 차이를 시각화한 결과를 포함합니다.

이 폴더는 전체 실험 백업본이 아니라, 최종 결과 확인과 재현 설명을 위한 제출용 축약본입니다.

## 2. 폴더 구조

```text
데마닝2_제출용_정리본/
├── README.md
├── requirements.txt
├── code/
│   ├── 01_sentiment_analysis_positive_evidence_recovery.py
│   └── 02~08_시각화_보조_스크립트.py
├── data/
│   ├── 통합_감성사전_v10_이상토큰정제.csv
│   └── 통합_감성사전_v10_삭제목록.csv
├── outputs/
│   ├── final_high_trust_reviews_sentiment_star_positive_recovery_review_view.csv
│   ├── final_high_trust_reviews_with_sentiment_star_positive_recovery_compact.csv
│   ├── positive_evidence_recovery_test_results.csv
│   ├── positive_recovery_sentiment_error_summary.csv
│   └── 주요 요약 CSV
├── figures/
│   └── 최종 보고서·발표용 PNG 그래프
└── docs/
    └── 분석 보고서, 해석 메모, 한계 설명
```

## 3. 주요 파일 설명

### code/01_sentiment_analysis_positive_evidence_recovery.py

High Trust 리뷰에 대해 최종 감성분석을 수행하는 핵심 코드입니다.  
주요 기능은 다음과 같습니다.

- 음식점 도메인 감성사전 불러오기
- 토큰 정규화 및 형태소 분석 오류 보정
- phrase rule 및 generalized pattern 기반 감성 근거 추출
- 부정문, 비교 대상, 양보절, 강도 표현 등 문맥 보정
- aspect별 감성점수 산출
- 최종 `sentiment_star` 산출
- 카카오 실제 별점과 비교하여 오차 분석용 CSV 생성

### data/통합_감성사전_v10_이상토큰정제.csv

최종 감성분석에 사용한 음식점 도메인 감성사전입니다.  
기본 열은 다음과 같습니다.

| 컬럼명 | 설명 |
|---|---|
| word | 감성 표현 |
| category | aspect 범주 |
| polarity | positive / negative |
| score | 감성 강도 점수 |

### outputs/final_high_trust_reviews_sentiment_star_positive_recovery_review_view.csv

최종 감성별점 결과를 리뷰 단위로 확인하기 위한 파일입니다.  
보고서와 발표에서 리뷰별 `sentiment_star`, 실제 별점과의 차이, aspect 점수 확인에 사용했습니다.

### outputs/final_high_trust_reviews_with_sentiment_star_positive_recovery_compact.csv

최종 감성분석 전체 결과의 축약본입니다.  
원본 전체 결과 파일은 크기가 커서 제출용 폴더에는 compact 버전을 포함했습니다.

### figures/

보고서 및 발표에 사용 가능한 최종 시각화 PNG 파일입니다.  
중간 실험용 그래프는 제외하고 최종 해석에 필요한 그래프만 남겼습니다.

## 4. 실행 방법

### 4.1 패키지 설치

```bash
pip install -r requirements.txt
```

### 4.2 감성분석 실행

감성분석 코드는 `data/` 폴더에 다음 입력 파일이 있을 때 실행할 수 있습니다.

```text
data/final_high_trust_reviews_pos.csv
data/통합_감성사전_v10_이상토큰정제.csv
```

실행 명령은 다음과 같습니다.

```bash
python code/01_sentiment_analysis_positive_evidence_recovery.py
```

실행 결과는 `outputs/` 폴더에 저장됩니다.

주의: 현재 제출용 정리본에는 최종 결과 CSV와 감성사전은 포함되어 있지만, 원본 입력 파일인 `final_high_trust_reviews_pos.csv`는 포함되어 있지 않을 수 있습니다. 재실행이 필요하면 전체 파이프라인에서 생성된 해당 파일을 `data/` 폴더에 추가해야 합니다.

## 5. 요구 패키지

이 정리본의 최종 감성분석 및 시각화 코드 확인에 필요한 주요 패키지는 다음과 같습니다.

```text
pandas
numpy
matplotlib
openpyxl
```

`re`, `json`, `pathlib`, `collections`, `unicodedata`, `sys` 등은 Python 기본 내장 모듈입니다.

## 6. 재현 및 확인 순서

보고서 검토 목적이라면 다음 순서로 확인하면 됩니다.

1. `outputs/`에서 최종 감성별점 결과 CSV 확인
2. `figures/`에서 발표·보고서용 시각화 확인
3. `code/01_sentiment_analysis_positive_evidence_recovery.py`에서 감성분석 규칙과 산출 방식 확인
4. `docs/`에서 오차 분석 및 해석 메모 확인

전체 크롤링, 수동 라벨 기반 trust score 평가, High Trust 선별 과정은 별도의 제출용 정리본에 포함된 trust filtering 코드와 데이터를 참고해야 합니다.

## 7. 포함하지 않은 파일

원본 압축파일에는 중간 실험 버전, 과거 결과 CSV, 번들 zip, 캐시 파일(`__pycache__`)이 다수 포함되어 있었습니다. 제출용 정리본에서는 다음 파일들을 제외했습니다.

- 과거 감성분석 버전 v14~v26
- 중간 튜닝 결과 CSV
- 중복 bundle zip
- Python 캐시 파일
- 중간 실험용 오차 진단 파일
- 발표에 사용하지 않은 임시 그래프

이 정리본은 최종 결과 확인에 필요한 핵심 코드, 결과, 표, 그래프를 중심으로 구성했습니다.
