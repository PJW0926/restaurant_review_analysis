"""
High Trust 리뷰의 식당별 aspect 다양성을 분석하고 발표용 시각화를 생성합니다.

분석 원칙:
- 기본 aspect: food, price, service, atmosphere
- 확장 행동·신뢰 aspect: wait, revisit, recommendation, hygiene
- 파일에 실제 존재하는 aspect만 사용
- general은 존재할 경우 보조 요약에만 포함
- 원점수 평균과 aspect별 상대 위치(z-score)를 함께 제공
"""

from pathlib import Path
import re

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import TwoSlopeNorm


INPUT_FILE = Path(
    r"C:\Users\eunse\OneDrive\바탕 화면\CSV 파일 합친거"
    r"\final_high_trust_reviews_sentiment_star_positive_recovery_review_view.csv"
)
OUTPUT_DIR = Path(__file__).resolve().parent

MIN_REVIEWS_FOR_PRESENTATION = 3
HEATMAP_STORE_COUNT = 15
REPRESENTATIVE_STORE_COUNT = 4

BASIC_ASPECTS = ["food", "price", "service", "atmosphere"]
EXPANDED_ASPECTS = ["wait", "revisit", "recommendation", "hygiene"]
AUXILIARY_ASPECTS = ["general"]

ASPECT_LABELS = {
    "food": "음식",
    "price": "가격",
    "service": "서비스",
    "atmosphere": "분위기",
    "wait": "웨이팅",
    "revisit": "재방문",
    "recommendation": "추천",
    "hygiene": "위생",
    "general": "일반",
}

BASIC_COLOR = "#277DA1"
EXPANDED_COLOR = "#F4A261"


def read_csv_safely(path):
    encodings = ["utf-8-sig", "utf-8", "cp949", "euc-kr"]
    last_error = None
    for encoding in encodings:
        try:
            return pd.read_csv(path, encoding=encoding), encoding
        except UnicodeDecodeError as error:
            last_error = error
    raise UnicodeDecodeError(
        "unknown", b"", 0, 1,
        f"CSV 인코딩을 읽지 못했습니다: {path} / 마지막 오류: {last_error}",
    )


def configure_korean_font():
    preferred = ["Malgun Gothic", "맑은 고딕", "AppleGothic", "NanumGothic"]
    installed = {font.name for font in font_manager.fontManager.ttflist}
    selected = next((font for font in preferred if font in installed), None)
    if selected:
        plt.rcParams["font.family"] = selected
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["figure.facecolor"] = "white"
    plt.rcParams["axes.facecolor"] = "white"
    return selected or "default"


def normalize_platform(value):
    text = str(value).strip().lower()
    if text in {"naver", "네이버"}:
        return "네이버"
    if text in {"kakao", "카카오"}:
        return "카카오"
    return str(value).strip()


def normalize_store_name(value):
    return re.sub(r"\s+", " ", str(value).strip())


def detect_aspects(df):
    requested_main = BASIC_ASPECTS + EXPANDED_ASPECTS
    available_main = [
        aspect for aspect in requested_main if f"{aspect}_score" in df.columns
    ]
    available_auxiliary = [
        aspect for aspect in AUXILIARY_ASPECTS if f"{aspect}_score" in df.columns
    ]
    missing_main = [aspect for aspect in requested_main if aspect not in available_main]
    return available_main, available_auxiliary, missing_main


def clean_frame(df, available_main, available_auxiliary):
    required = {"store_name", "sentiment_star"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"필수 컬럼이 없습니다: {missing}")

    result = df.copy()
    result["store_name"] = result["store_name"].apply(normalize_store_name)
    result["store_key"] = result["store_name"].str.replace(r"\s+", "", regex=True)
    result["sentiment_star"] = pd.to_numeric(result["sentiment_star"], errors="coerce")
    if "platform" in result.columns:
        result["platform"] = result["platform"].apply(normalize_platform)

    for aspect in available_main + available_auxiliary:
        column = f"{aspect}_score"
        result[column] = pd.to_numeric(result[column], errors="coerce")

    return result.loc[
        result["store_key"].ne("") & result["sentiment_star"].notna()
    ].copy()


def display_name_map(df):
    return (
        df.groupby("store_key")["store_name"]
        .agg(lambda values: values.value_counts().index[0])
        .rename("store_name")
        .reset_index()
    )


def build_store_summary(df, available_main, available_auxiliary):
    score_columns = [
        f"{aspect}_score" for aspect in available_main + available_auxiliary
    ]
    aggregation = {
        "review_count": ("sentiment_star", "count"),
        "sentiment_star_mean": ("sentiment_star", "mean"),
        "sentiment_star_median": ("sentiment_star", "median"),
    }
    for column in score_columns:
        aggregation[column] = (column, "mean")

    summary = df.groupby("store_key").agg(**aggregation).reset_index()
    summary = summary.merge(display_name_map(df), on="store_key", how="left")

    main_columns = [f"{aspect}_score" for aspect in available_main]
    summary["strongest_aspect"] = (
        summary[main_columns].idxmax(axis=1).str.removesuffix("_score")
    )
    summary["strongest_aspect_score"] = summary[main_columns].max(axis=1)
    summary["weakest_aspect"] = (
        summary[main_columns].idxmin(axis=1).str.removesuffix("_score")
    )
    summary["weakest_aspect_score"] = summary[main_columns].min(axis=1)
    summary["aspect_gap"] = (
        summary["strongest_aspect_score"] - summary["weakest_aspect_score"]
    )
    summary["eligible_for_presentation"] = (
        summary["review_count"] >= MIN_REVIEWS_FOR_PRESENTATION
    )

    # Aspect마다 점수 범위와 탐지 빈도가 다르므로, 식당이 각 aspect에서
    # 전체 식당 대비 어느 위치인지 확인하는 상대 점수도 함께 계산합니다.
    eligible_mask = summary["eligible_for_presentation"]
    for aspect in available_main:
        column = f"{aspect}_score"
        values = summary.loc[eligible_mask, column]
        std = values.std(ddof=0)
        z_column = f"{aspect}_relative_z"
        if std == 0 or pd.isna(std):
            summary[z_column] = 0.0
        else:
            summary[z_column] = (summary[column] - values.mean()) / std

    z_columns = [f"{aspect}_relative_z" for aspect in available_main]
    summary["relative_strongest_aspect"] = (
        summary[z_columns].idxmax(axis=1).str.removesuffix("_relative_z")
    )
    summary["relative_strongest_z"] = summary[z_columns].max(axis=1)
    summary["relative_weakest_aspect"] = (
        summary[z_columns].idxmin(axis=1).str.removesuffix("_relative_z")
    )
    summary["relative_weakest_z"] = summary[z_columns].min(axis=1)
    summary["relative_profile_gap"] = (
        summary["relative_strongest_z"] - summary["relative_weakest_z"]
    )
    summary["aspect_active_count"] = (
        summary[main_columns].abs().gt(1e-12).sum(axis=1)
    )

    front = [
        "store_name", "store_key", "review_count", "sentiment_star_mean",
        "sentiment_star_median",
    ]
    remaining = [column for column in summary.columns if column not in front]
    return summary[front + remaining].sort_values(
        "relative_profile_gap", ascending=False
    ).reset_index(drop=True)


def build_strength_weakness(store_summary):
    columns = [
        "store_name", "review_count", "sentiment_star_mean",
        "strongest_aspect", "strongest_aspect_score",
        "weakest_aspect", "weakest_aspect_score", "aspect_gap",
        "relative_strongest_aspect", "relative_strongest_z",
        "relative_weakest_aspect", "relative_weakest_z",
        "relative_profile_gap", "aspect_active_count",
        "eligible_for_presentation",
    ]
    return store_summary[columns].copy()


def build_overall_aspect_summary(df, available_main):
    records = []
    for aspect in available_main:
        column = f"{aspect}_score"
        values = df[column].dropna()
        nonzero = values.loc[values.abs() > 1e-12]
        records.append(
            {
                "aspect": aspect,
                "aspect_group": (
                    "기본 평가 aspect" if aspect in BASIC_ASPECTS
                    else "확장 행동·신뢰 aspect"
                ),
                "review_count": len(values),
                "mean_score": float(values.mean()),
                "median_score": float(values.median()),
                "std_score": float(values.std(ddof=1)),
                "nonzero_review_count": len(nonzero),
                "nonzero_ratio": len(nonzero) / len(values),
                "mean_score_when_nonzero": (
                    float(nonzero.mean()) if len(nonzero) else np.nan
                ),
            }
        )
    return pd.DataFrame(records)


def build_platform_aspect_summary(df, available_main):
    if "platform" not in df.columns:
        return pd.DataFrame()
    rows = []
    for platform, group in df.groupby("platform"):
        record = {"platform": platform, "review_count": len(group)}
        for aspect in available_main:
            record[f"{aspect}_mean"] = float(group[f"{aspect}_score"].mean())
        rows.append(record)
    return pd.DataFrame(rows)


def choose_heatmap_stores(eligible):
    # 상대 프로필 차이가 큰 식당을 우선하되, 리뷰 수가 지나치게 적은 사례가
    # 발표를 지배하지 않도록 리뷰 수 순위도 함께 반영합니다.
    ranked = eligible.copy()
    ranked["profile_rank"] = ranked["relative_profile_gap"].rank(
        ascending=False, method="min"
    )
    ranked["review_rank"] = ranked["review_count"].rank(
        ascending=False, method="min"
    )
    ranked["selection_rank"] = ranked["profile_rank"] + 0.25 * ranked["review_rank"]
    return ranked.nsmallest(HEATMAP_STORE_COUNT, "selection_rank").copy()


def choose_representative_stores(eligible):
    selected = []
    for aspect in [a for a in BASIC_ASPECTS + EXPANDED_ASPECTS if f"{a}_relative_z" in eligible]:
        candidate = eligible.nlargest(1, f"{aspect}_relative_z")
        if not candidate.empty:
            key = candidate.iloc[0]["store_key"]
            if key not in selected:
                selected.append(key)
        if len(selected) >= REPRESENTATIVE_STORE_COUNT:
            break
    if len(selected) < REPRESENTATIVE_STORE_COUNT:
        for key in eligible.sort_values(
            ["relative_profile_gap", "review_count"], ascending=[False, False]
        )["store_key"]:
            if key not in selected:
                selected.append(key)
            if len(selected) >= REPRESENTATIVE_STORE_COUNT:
                break
    return eligible.loc[eligible["store_key"].isin(selected)].copy()


def save_store_heatmap(selected, available_main):
    raw_columns = [f"{aspect}_score" for aspect in available_main]
    z_columns = [f"{aspect}_relative_z" for aspect in available_main]
    selected = selected.sort_values("relative_profile_gap", ascending=False)
    raw = selected.set_index("store_name")[raw_columns]
    raw.columns = [ASPECT_LABELS[aspect] for aspect in available_main]
    relative = selected.set_index("store_name")[z_columns]
    relative.columns = [ASPECT_LABELS[aspect] for aspect in available_main]

    fig, axes = plt.subplots(
        1, 2, figsize=(17, max(8, len(selected) * 0.48 + 2.5)),
        gridspec_kw={"width_ratios": [1, 1.08]},
    )

    raw_max = max(0.5, float(np.nanmax(np.abs(raw.values))))
    raw_norm = TwoSlopeNorm(vmin=-raw_max, vcenter=0, vmax=raw_max)
    raw_image = axes[0].imshow(raw.values, cmap="RdYlGn", norm=raw_norm, aspect="auto")
    axes[0].set_title("식당별 원점수 평균", fontsize=14, fontweight="bold")
    axes[0].set_xticks(np.arange(len(raw.columns)))
    axes[0].set_xticklabels(raw.columns, rotation=35, ha="right")
    axes[0].set_yticks(np.arange(len(raw.index)))
    axes[0].set_yticklabels(raw.index)
    for row in range(raw.shape[0]):
        for column in range(raw.shape[1]):
            axes[0].text(
                column, row, f"{raw.iloc[row, column]:+.2f}",
                ha="center", va="center", fontsize=7.5,
            )

    relative_max = max(1.0, float(np.nanmax(np.abs(relative.values))))
    relative_norm = TwoSlopeNorm(vmin=-relative_max, vcenter=0, vmax=relative_max)
    relative_image = axes[1].imshow(
        relative.values, cmap="RdBu_r", norm=relative_norm, aspect="auto"
    )
    axes[1].set_title(
        "Aspect별 전체 식당 대비 상대 위치",
        fontsize=14,
        fontweight="bold",
    )
    axes[1].set_xticks(np.arange(len(relative.columns)))
    axes[1].set_xticklabels(relative.columns, rotation=35, ha="right")
    axes[1].set_yticks(np.arange(len(relative.index)))
    axes[1].set_yticklabels([])
    for row in range(relative.shape[0]):
        for column in range(relative.shape[1]):
            axes[1].text(
                column, row, f"{relative.iloc[row, column]:+.1f}",
                ha="center", va="center", fontsize=7.5,
            )

    basic_count = sum(aspect in BASIC_ASPECTS for aspect in available_main)
    if 0 < basic_count < len(available_main):
        for ax in axes:
            ax.axvline(basic_count - 0.5, color="#222222", linewidth=2)

    fig.colorbar(raw_image, ax=axes[0], shrink=0.55, label="평균 aspect 점수")
    fig.colorbar(relative_image, ax=axes[1], shrink=0.55, label="식당 간 표준화 z-score")
    fig.suptitle("식당별 Aspect 점수 Heatmap", fontsize=19, fontweight="bold", y=1.01)
    fig.text(
        0.5, 0.002,
        "검은 구분선 왼쪽: 기본 평가 aspect · 오른쪽: 확장 행동·신뢰 aspect",
        ha="center", fontsize=10, color="#555555",
    )
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "fig_store_aspect_heatmap.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def save_representative_bar(representative, available_main):
    representative = representative.sort_values(
        "relative_profile_gap", ascending=False
    )
    aspects = available_main
    basic_aspects = [aspect for aspect in aspects if aspect in BASIC_ASPECTS]
    expanded_aspects = [aspect for aspect in aspects if aspect in EXPANDED_ASPECTS]
    width = 0.8 / len(representative)

    fig, axes = plt.subplots(
        1,
        2,
        figsize=(14.5, 7.3),
        gridspec_kw={"width_ratios": [1.15, 1]},
    )
    colors = plt.cm.Set2(np.linspace(0, 1, len(representative)))

    def draw_group(ax, group_aspects, title, subtitle, show_ylabel=False):
        labels = [ASPECT_LABELS[aspect] for aspect in group_aspects]
        x = np.arange(len(group_aspects))
        for index, (_, row) in enumerate(representative.iterrows()):
            values = [row[f"{aspect}_score"] for aspect in group_aspects]
            positions = x - 0.4 + width / 2 + index * width
            ax.bar(
                positions,
                values,
                width=width,
                label=row["store_name"],
                color=colors[index],
                edgecolor="#555555",
                linewidth=0.45,
            )

        ax.axhline(0, color="#333333", linewidth=1)
        ax.set_xticks(x)
        ax.set_xticklabels(labels, fontsize=12)
        ax.tick_params(axis="y", labelsize=11)
        ax.set_title(
            f"{title}\n{subtitle}",
            fontsize=13.5,
            fontweight="bold",
            color="#222222",
            pad=12,
        )
        ax.grid(axis="y", linestyle="--", alpha=0.22)
        if show_ylabel:
            ax.set_ylabel("평균 aspect 점수", fontsize=12.5)

    draw_group(
        axes[0],
        basic_aspects,
        "기본 평가 aspect",
        "음식·가격·서비스·분위기",
        show_ylabel=True,
    )
    draw_group(
        axes[1],
        expanded_aspects,
        "확장 행동·신뢰 aspect",
        "웨이팅·재방문·위생 (확대 축)",
    )

    basic_values = [
        row[f"{aspect}_score"]
        for _, row in representative.iterrows()
        for aspect in basic_aspects
    ]
    expanded_values = [
        row[f"{aspect}_score"]
        for _, row in representative.iterrows()
        for aspect in expanded_aspects
    ]
    axes[0].set_ylim(
        min(-0.08, min(basic_values) * 1.2),
        max(2.8, max(basic_values) * 1.12),
    )
    axes[1].set_ylim(
        min(-0.08, min(expanded_values) * 1.25),
        max(0.48, max(expanded_values) * 1.22),
    )

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper center",
        bbox_to_anchor=(0.5, 0.875),
        ncol=4,
        frameon=False,
        fontsize=11,
    )
    fig.suptitle(
        "대표 식당별 Aspect 강점·약점 비교",
        fontsize=19,
        fontweight="bold",
        y=0.985,
    )
    fig.text(
        0.5,
        0.03,
        "왼쪽은 기본 평가 영역, 오른쪽은 행동·신뢰 신호를 분리해 식당별 프로필 차이를 보여준다.",
        ha="center",
        fontsize=10.5,
        color="#555555",
    )
    fig.tight_layout(rect=[0, 0.06, 1, 0.835])
    fig.savefig(
        OUTPUT_DIR / "fig_representative_store_aspect_bar.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def save_overall_aspect_bar(overall, available_main):
    plot_df = overall.set_index("aspect").loc[available_main].reset_index()
    colors = [
        BASIC_COLOR if aspect in BASIC_ASPECTS else EXPANDED_COLOR
        for aspect in plot_df["aspect"]
    ]
    labels = [ASPECT_LABELS[aspect] for aspect in plot_df["aspect"]]

    fig, ax = plt.subplots(figsize=(10.8, 7.0))
    y = np.arange(len(plot_df))
    bars = ax.barh(y, plot_df["mean_score"], color=colors, height=0.68)
    ax.axvline(0, color="#333333", linewidth=1)
    boundary = sum(aspect in BASIC_ASPECTS for aspect in available_main)
    if 0 < boundary < len(available_main):
        ax.axhspan(-0.5, boundary - 0.5, color="#E8F4F8", alpha=0.30, zorder=0)
        ax.axhspan(
            boundary - 0.5, len(available_main) - 0.5,
            color="#FFF2E5", alpha=0.42, zorder=0,
        )
        ax.axhline(boundary - 0.5, color="#333333", linewidth=1.5)
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=12.5)
    ax.invert_yaxis()
    ax.set_xlabel("전체 High Trust 리뷰 평균 aspect 점수", fontsize=12.5)
    ax.set_title(
        "전체 리뷰 기준 Aspect 평균 점수 비교",
        fontsize=19,
        fontweight="bold",
        pad=34,
    )
    ax.text(
        0.5,
        1.025,
        "막대는 평균 점수, 라벨은 평균 점수와 해당 aspect evidence(근거) 출현률을 함께 표시",
        transform=ax.transAxes,
        ha="center",
        va="bottom",
        fontsize=11,
        color="#666666",
    )
    ax.grid(axis="x", linestyle="--", alpha=0.25)
    ax.tick_params(axis="x", labelsize=11.5)
    minimum = float(plot_df["mean_score"].min())
    maximum = float(plot_df["mean_score"].max())
    span = max(0.5, maximum - minimum)
    ax.set_xlim(min(-0.12, minimum - span * 0.04), maximum + span * 0.25)
    x_left, x_right = ax.get_xlim()
    group_x = x_right - (x_right - x_left) * 0.045
    if 0 < boundary < len(available_main):
        ax.text(
            group_x,
            (boundary - 1) / 2,
            "기본 평가\naspect",
            ha="right",
            va="center",
            fontsize=10.5,
            color="#245A6B",
            fontweight="bold",
        )
        ax.text(
            group_x,
            boundary + (len(available_main) - boundary - 1) / 2,
            "확장 행동·신뢰\naspect",
            ha="right",
            va="center",
            fontsize=10.5,
            color="#A45B1F",
            fontweight="bold",
        )
    for bar, mean, ratio in zip(
        bars, plot_df["mean_score"], plot_df["nonzero_ratio"]
    ):
        offset = span * 0.015
        # Negative bars are short and close to the y-axis, so their long
        # annotation is placed to the right of zero for presentation clarity.
        label_x = mean + offset if mean >= 0 else offset
        ax.text(
            label_x,
            bar.get_y() + bar.get_height() / 2,
            f"{mean:+.3f} · evidence {ratio:.1%}",
            va="center",
            ha="left",
            fontsize=10.5,
            fontweight="bold",
        )
    fig.text(
        0.5, 0.015,
        "파란색: 기본 평가 aspect · 주황색: 확장 행동·신뢰 aspect",
        ha="center", fontsize=10.5, color="#555555",
    )
    fig.tight_layout(rect=[0, 0.04, 1, 0.95])
    fig.savefig(
        OUTPUT_DIR / "fig_overall_aspect_average.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def save_platform_comparison(platform_summary, available_main):
    if platform_summary.empty:
        return
    platforms = platform_summary["platform"].tolist()
    matrix = platform_summary.set_index("platform")[
        [f"{aspect}_mean" for aspect in available_main]
    ].T
    matrix.index = [ASPECT_LABELS[aspect] for aspect in available_main]
    if {"네이버", "카카오"}.issubset(matrix.columns):
        matrix["차이\n(네이버-카카오)"] = matrix["네이버"] - matrix["카카오"]
        matrix = matrix[["네이버", "카카오", "차이\n(네이버-카카오)"]]

    max_abs = max(0.4, float(np.nanmax(np.abs(matrix.values))))
    norm = TwoSlopeNorm(vmin=-max_abs, vcenter=0, vmax=max_abs)
    fig, ax = plt.subplots(figsize=(9.5, 7))
    image = ax.imshow(matrix.values, cmap="RdYlGn", norm=norm, aspect="auto")
    ax.set_xticks(np.arange(len(matrix.columns)))
    ax.set_xticklabels(matrix.columns)
    ax.set_yticks(np.arange(len(matrix.index)))
    ax.set_yticklabels(matrix.index)
    ax.set_title(
        "플랫폼별 Aspect 평균 점수 비교",
        fontsize=17,
        fontweight="bold",
        pad=16,
    )
    for row in range(matrix.shape[0]):
        for column in range(matrix.shape[1]):
            ax.text(
                column, row, f"{matrix.iloc[row, column]:+.3f}",
                ha="center", va="center",
                fontweight="bold" if column == matrix.shape[1] - 1 else "normal",
            )
    boundary = sum(aspect in BASIC_ASPECTS for aspect in available_main)
    if 0 < boundary < len(available_main):
        ax.axhline(boundary - 0.5, color="#222222", linewidth=2)
    fig.colorbar(image, ax=ax, shrink=0.8, label="평균 aspect 점수")
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "fig_platform_aspect_comparison.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def build_interpretation(
    store_summary, strength_weakness, overall, representative,
    available_main, missing_main,
):
    eligible = store_summary.loc[store_summary["eligible_for_presentation"]]
    strongest_counts = strength_weakness.loc[
        strength_weakness["eligible_for_presentation"], "relative_strongest_aspect"
    ].value_counts()
    weakest_counts = strength_weakness.loc[
        strength_weakness["eligible_for_presentation"], "relative_weakest_aspect"
    ].value_counts()

    top_overall = overall.nlargest(1, "mean_score").iloc[0]
    low_overall = overall.nsmallest(1, "mean_score").iloc[0]
    rep_text = ", ".join(
        (
            f"{row.store_name}"
            f"({ASPECT_LABELS[row.relative_strongest_aspect]} 측면이 상대적으로 높고, "
            f"{ASPECT_LABELS[row.relative_weakest_aspect]} 측면이 상대적으로 낮음)"
        )
        for row in representative.itertuples()
    )
    basic_used = [ASPECT_LABELS[a] for a in available_main if a in BASIC_ASPECTS]
    expanded_used = [ASPECT_LABELS[a] for a in available_main if a in EXPANDED_ASPECTS]
    missing_text = (
        f" 현재 파일에는 {', '.join(ASPECT_LABELS[a] for a in missing_main)} 점수가 없어 제외했다."
        if missing_main else ""
    )

    return [
        (
            "본 분석은 단일 감성 별점뿐 아니라 기본 평가 aspect "
            f"({', '.join(basic_used)})와 확장 행동·신뢰 aspect "
            f"({', '.join(expanded_used)})를 함께 사용했다.{missing_text}"
        ),
        (
            f"전체 High Trust 리뷰에서 평균 점수가 가장 높은 aspect는 "
            f"{ASPECT_LABELS[top_overall['aspect']]}({top_overall['mean_score']:+.3f})였고, "
            f"가장 낮은 aspect는 {ASPECT_LABELS[low_overall['aspect']]}"
            f"({low_overall['mean_score']:+.3f})였다."
        ),
        (
            f"리뷰가 {MIN_REVIEWS_FOR_PRESENTATION}개 이상인 {len(eligible)}개 식당의 "
            "aspect별 상대 위치를 비교한 결과, 식당마다 상대적으로 높고 낮은 평가 영역의 "
            "조합이 다르게 나타났다."
        ),
        f"대표 사례는 {rep_text}이다.",
        (
            "따라서 본 프로젝트는 전체 평점이나 기본 4개 aspect에만 머물지 않고, "
            "재방문·웨이팅·위생과 같은 행동·신뢰 신호까지 활용해 식당별 차별적 강점과 "
            "개선 영역을 해석할 수 있다는 점에서 차별성이 있다."
        ),
    ]


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"입력 파일을 찾을 수 없습니다: {INPUT_FILE}")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    selected_font = configure_korean_font()
    raw_df, encoding = read_csv_safely(INPUT_FILE)
    available_main, available_auxiliary, missing_main = detect_aspects(raw_df)
    if not available_main:
        raise ValueError("사용 가능한 main aspect 점수 컬럼이 없습니다.")
    df = clean_frame(raw_df, available_main, available_auxiliary)

    store_summary = build_store_summary(df, available_main, available_auxiliary)
    strength_weakness = build_strength_weakness(store_summary)
    overall = build_overall_aspect_summary(df, available_main)
    platform_summary = build_platform_aspect_summary(df, available_main)
    eligible = store_summary.loc[store_summary["eligible_for_presentation"]].copy()
    heatmap_stores = choose_heatmap_stores(eligible)
    representative = choose_representative_stores(eligible)

    store_summary.to_csv(
        OUTPUT_DIR / "store_aspect_average_summary.csv",
        index=False, encoding="utf-8-sig",
    )
    strength_weakness.to_csv(
        OUTPUT_DIR / "store_aspect_strength_weakness.csv",
        index=False, encoding="utf-8-sig",
    )
    overall.to_csv(
        OUTPUT_DIR / "overall_aspect_average.csv",
        index=False, encoding="utf-8-sig",
    )
    heatmap_stores.to_csv(
        OUTPUT_DIR / "heatmap_selected_stores.csv",
        index=False, encoding="utf-8-sig",
    )
    representative.to_csv(
        OUTPUT_DIR / "representative_store_aspect_summary.csv",
        index=False, encoding="utf-8-sig",
    )
    if not platform_summary.empty:
        platform_summary.to_csv(
            OUTPUT_DIR / "platform_aspect_average.csv",
            index=False, encoding="utf-8-sig",
        )

    save_store_heatmap(heatmap_stores, available_main)
    save_representative_bar(representative, available_main)
    save_overall_aspect_bar(overall, available_main)
    save_platform_comparison(platform_summary, available_main)

    interpretation = build_interpretation(
        store_summary, strength_weakness, overall, representative,
        available_main, missing_main,
    )
    (OUTPUT_DIR / "aspect_diversity_interpretation.txt").write_text(
        "\n\n".join(interpretation) + "\n", encoding="utf-8",
    )

    method_lines = [
        "Aspect 다양성 분석 기준 및 한계",
        "",
        f"- 사용 기본 aspect: {', '.join(a for a in available_main if a in BASIC_ASPECTS)}",
        f"- 사용 확장 aspect: {', '.join(a for a in available_main if a in EXPANDED_ASPECTS)}",
        f"- 파일에 없어 제외한 aspect: {', '.join(missing_main) if missing_main else '없음'}",
        f"- 발표용 식당 기준: 리뷰 {MIN_REVIEWS_FOR_PRESENTATION}개 이상",
        "- 원점수 강점/약점은 식당 내부에서 가장 높은/낮은 평균 aspect로 계산했습니다.",
        "- Aspect마다 점수 범위와 근거 출현 빈도가 달라, 발표 heatmap에는 식당 간 상대 z-score도 함께 표시했습니다.",
        "- 0점은 해당 aspect가 중립이라는 뜻뿐 아니라 감성 근거가 탐지되지 않았다는 의미도 포함할 수 있습니다.",
        "- 따라서 상대적으로 낮은 aspect를 실제 불만이나 약점으로 단정하지 않고, 개선 후보 또는 관련 근거 부족 가능성으로 해석해야 합니다.",
        "- Recommendation과 general은 현재 review-view CSV에 없어 분석에서 제외했습니다.",
        "- 결과는 High Trust 리뷰 집합에 대한 기술통계이며 인과관계를 의미하지 않습니다.",
    ]
    (OUTPUT_DIR / "aspect_diversity_method_limitations.txt").write_text(
        "\n".join(method_lines) + "\n", encoding="utf-8",
    )

    print(f"[입력 인코딩] {encoding}")
    print(f"[한글 폰트] {selected_font}")
    print(f"[분석 리뷰 수] {len(df):,}")
    print(f"[분석 식당 수] {len(store_summary):,}")
    print(f"[발표 기준 충족 식당 수] {len(eligible):,}")
    print(f"[사용 기본 aspect] {[a for a in available_main if a in BASIC_ASPECTS]}")
    print(f"[사용 확장 aspect] {[a for a in available_main if a in EXPANDED_ASPECTS]}")
    print(f"[파일에 없어 제외] {missing_main}")
    print("\n[전체 aspect 평균]")
    print(overall.to_string(index=False))
    print("\n[대표 식당]")
    print(
        representative[
            [
                "store_name", "review_count", "sentiment_star_mean",
                "relative_strongest_aspect", "relative_weakest_aspect",
                "relative_profile_gap",
            ]
        ].to_string(index=False)
    )
    print("\n[발표용 해석]")
    for line in interpretation:
        print(f"- {line}")
    print(f"\n[산출물 폴더] {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
