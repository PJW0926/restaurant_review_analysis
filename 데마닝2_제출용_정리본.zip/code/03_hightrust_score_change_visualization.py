"""
전체 리뷰와 High Trust 리뷰의 감성 별점을 비교하는 발표용 분석 및 시각화.

중요:
- 전체 평균 비교는 리뷰 단위 가중 평균입니다.
- 식당별 변화 비교는 각 식당의 평균 점수를 먼저 계산한 뒤 비교합니다.
- High Trust 리뷰 수와 전체 리뷰 수가 각각 3개 이상인 식당만 발표용 그래프에 사용합니다.
- 숫자는 입력 CSV에서 실제 계산합니다.
"""

from pathlib import Path
import math
import re

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import TwoSlopeNorm


ALL_REVIEWS_FILE = Path(
    r"C:\Users\eunse\OneDrive\바탕 화면\CSV 파일 합친거"
    r"\all_reviews_sentiment_star_positive_recovery_review_view.csv"
)
HIGH_TRUST_FILE = Path(
    r"C:\Users\eunse\OneDrive\바탕 화면\CSV 파일 합친거"
    r"\final_high_trust_reviews_sentiment_star_positive_recovery_review_view.csv"
)
OUTPUT_DIR = Path(__file__).resolve().parent

MIN_ALL_REVIEWS = 3
MIN_HIGH_TRUST_REVIEWS = 3
TOP_N_LARGEST = 15
TOP_N_INCREASE_DECREASE = 5

ASPECT_COLUMNS = [
    "food_score",
    "service_score",
    "price_score",
    "atmosphere_score",
    "wait_score",
    "revisit_score",
    "recommendation_score",
    "hygiene_score",
    "general_score",
]

BEFORE_COLOR = "#7A7A7A"
AFTER_COLOR = "#277DA1"
INCREASE_COLOR = "#2E8B57"
DECREASE_COLOR = "#D95F59"


def read_csv_safely(path):
    encodings = ["utf-8-sig", "utf-8", "cp949", "euc-kr"]
    last_error = None
    for encoding in encodings:
        try:
            return pd.read_csv(path, encoding=encoding), encoding
        except UnicodeDecodeError as error:
            last_error = error
    raise UnicodeDecodeError(
        "unknown", b"", 0, 1,
        f"CSV 인코딩을 읽지 못했습니다: {path} / 마지막 오류: {last_error}",
    )


def configure_korean_font():
    preferred = ["Malgun Gothic", "맑은 고딕", "AppleGothic", "NanumGothic"]
    installed = {font.name for font in font_manager.fontManager.ttflist}
    selected = next((name for name in preferred if name in installed), None)
    if selected:
        plt.rcParams["font.family"] = selected
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["figure.facecolor"] = "white"
    plt.rcParams["axes.facecolor"] = "white"
    return selected or "default"


def normalize_platform(value):
    text = str(value).strip().lower()
    if text in {"naver", "네이버"}:
        return "네이버"
    if text in {"kakao", "카카오"}:
        return "카카오"
    return str(value).strip()


def normalize_store_name(value):
    return re.sub(r"\s+", " ", str(value).strip())


def sample_std(series):
    return float(series.std(ddof=1)) if len(series) > 1 else 0.0


def clean_frame(df):
    required = {"store_name", "review_text", "sentiment_star"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"필수 컬럼이 없습니다: {missing}")

    result = df.copy()
    result["store_name"] = result["store_name"].apply(normalize_store_name)
    # 비교 키에서는 공백을 제거해 "할머니의 레시피"와 "할머니의레시피"처럼
    # 공백만 다른 동일 식당이 분리되지 않게 합니다. 표시명은 원래 형태를 보존합니다.
    result["store_key"] = result["store_name"].str.replace(r"\s+", "", regex=True)
    result["sentiment_star"] = pd.to_numeric(result["sentiment_star"], errors="coerce")
    if "platform" in result.columns:
        result["platform"] = result["platform"].apply(normalize_platform)

    numeric_columns = ["rating"] + [
        column for column in ASPECT_COLUMNS if column in result.columns
    ]
    for column in numeric_columns:
        if column in result.columns:
            result[column] = pd.to_numeric(result[column], errors="coerce")

    return result.loc[
        result["store_key"].ne("") & result["sentiment_star"].notna()
    ].copy()


def describe_scores(series):
    values = series.dropna()
    return {
        "review_count": len(values),
        "mean": float(values.mean()),
        "median": float(values.median()),
        "std": sample_std(values),
    }


def build_overall_summary(all_df, high_df):
    before = describe_scores(all_df["sentiment_star"])
    after = describe_scores(high_df["sentiment_star"])
    return pd.DataFrame(
        [
            {
                "score_before": before["mean"],
                "score_after": after["mean"],
                "score_change": after["mean"] - before["mean"],
                "all_review_count": before["review_count"],
                "high_trust_review_count": after["review_count"],
                "retention_rate": after["review_count"] / before["review_count"],
                "all_median": before["median"],
                "high_trust_median": after["median"],
                "all_std": before["std"],
                "high_trust_std": after["std"],
            }
        ]
    )


def aggregate_stores(df, prefix):
    return (
        df.groupby("store_key")["sentiment_star"]
        .agg(["count", "mean", "median", "std"])
        .rename(
            columns={
                "count": f"{prefix}_review_count",
                "mean": f"{prefix}_mean",
                "median": f"{prefix}_median",
                "std": f"{prefix}_std",
            }
        )
        .reset_index()
    )


def build_store_change(all_df, high_df):
    before = aggregate_stores(all_df, "all")
    after = aggregate_stores(high_df, "high_trust")
    merged = before.merge(after, on="store_key", how="outer")

    combined_names = pd.concat(
        [
            all_df[["store_key", "store_name"]],
            high_df[["store_key", "store_name"]],
        ],
        ignore_index=True,
    )
    display_names = (
        combined_names.groupby("store_key")["store_name"]
        .agg(lambda values: values.value_counts().index[0])
        .rename("store_name")
        .reset_index()
    )
    merged = merged.merge(display_names, on="store_key", how="left")
    merged["score_before"] = merged["all_mean"]
    merged["score_after"] = merged["high_trust_mean"]
    merged["score_change"] = merged["score_after"] - merged["score_before"]
    merged["abs_change"] = merged["score_change"].abs()
    merged["change_direction"] = np.select(
        [
            merged["score_change"] > 1e-12,
            merged["score_change"] < -1e-12,
        ],
        ["상승", "하락"],
        default="변화 없음",
    )
    merged["high_trust_retention_rate"] = (
        merged["high_trust_review_count"] / merged["all_review_count"]
    )
    merged["eligible_for_presentation"] = (
        (merged["all_review_count"] >= MIN_ALL_REVIEWS)
        & (merged["high_trust_review_count"] >= MIN_HIGH_TRUST_REVIEWS)
        & merged["score_before"].notna()
        & merged["score_after"].notna()
    )
    return merged.sort_values("abs_change", ascending=False).reset_index(drop=True)


def build_platform_summary(all_df, high_df):
    if "platform" not in all_df.columns or "platform" not in high_df.columns:
        return pd.DataFrame()

    rows = []
    platforms = sorted(set(all_df["platform"]) | set(high_df["platform"]))
    for platform in platforms:
        before = describe_scores(
            all_df.loc[all_df["platform"] == platform, "sentiment_star"]
        )
        after = describe_scores(
            high_df.loc[high_df["platform"] == platform, "sentiment_star"]
        )
        if before["review_count"] == 0 or after["review_count"] == 0:
            continue
        rows.append(
            {
                "platform": platform,
                "all_review_count": before["review_count"],
                "high_trust_review_count": after["review_count"],
                "score_before": before["mean"],
                "score_after": after["mean"],
                "score_change": after["mean"] - before["mean"],
                "retention_rate": after["review_count"] / before["review_count"],
            }
        )
    return pd.DataFrame(rows)


def build_aspect_summary(all_df, high_df):
    available = [
        column
        for column in ASPECT_COLUMNS
        if column in all_df.columns and column in high_df.columns
    ]
    rows = []
    for column in available:
        before = float(all_df[column].mean())
        after = float(high_df[column].mean())
        rows.append(
            {
                "aspect": column.removesuffix("_score"),
                "score_before": before,
                "score_after": after,
                "score_change": after - before,
            }
        )
    return pd.DataFrame(rows)


def bootstrap_store_change_summary(eligible):
    changes = eligible["score_change"].dropna().to_numpy(dtype=float)
    rng = np.random.default_rng(20260615)
    bootstrap_means = np.array(
        [
            rng.choice(changes, size=len(changes), replace=True).mean()
            for _ in range(20000)
        ]
    )
    ci_low, ci_high = np.quantile(bootstrap_means, [0.025, 0.975])
    return pd.DataFrame(
        [
            {
                "eligible_store_count": len(eligible),
                "mean_store_score_change": changes.mean(),
                "median_store_score_change": np.median(changes),
                "store_change_std": sample_std(pd.Series(changes)),
                "bootstrap_ci95_low": ci_low,
                "bootstrap_ci95_high": ci_high,
                "increase_store_count": int((changes > 0).sum()),
                "decrease_store_count": int((changes < 0).sum()),
                "no_change_store_count": int((changes == 0).sum()),
            }
        ]
    )


def save_overall_figure(overall):
    row = overall.iloc[0]
    labels = ["전체 리뷰", "High Trust 리뷰"]
    values = [row["score_before"], row["score_after"]]
    counts = [int(row["all_review_count"]), int(row["high_trust_review_count"])]

    fig, ax = plt.subplots(figsize=(9.8, 6.2))
    bars = ax.bar(
        labels,
        values,
        color=[BEFORE_COLOR, AFTER_COLOR],
        width=0.50,
        edgecolor="white",
        linewidth=1.5,
    )
    ax.set_ylim(0, 5.3)
    ax.set_ylabel("평균 감성 별점", fontsize=13)
    ax.set_title(
        "전체 리뷰와 High Trust 리뷰의 평균 감성 별점 비교",
        fontsize=19,
        fontweight="bold",
        pad=16,
    )
    ax.grid(axis="y", linestyle="--", alpha=0.28)
    ax.tick_params(axis="x", labelsize=13)
    ax.tick_params(axis="y", labelsize=12)
    for bar, value, count in zip(bars, values, counts):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            value + 0.1,
            f"{value:.3f}점\n(n={count:,})",
            ha="center",
            va="bottom",
            fontsize=12.5,
            fontweight="bold",
        )

    arrow_y = 4.72
    ax.annotate(
        "",
        xy=(0.86, arrow_y),
        xytext=(0.14, arrow_y),
        arrowprops={
            "arrowstyle": "->",
            "color": AFTER_COLOR,
            "linewidth": 2.4,
            "shrinkA": 0,
            "shrinkB": 0,
        },
    )
    ax.text(
        0.5,
        arrow_y + 0.13,
        f"{row['score_change']:+.3f}점 상승",
        ha="center",
        va="bottom",
        fontsize=13.5,
        fontweight="bold",
        color=AFTER_COLOR,
        bbox={
            "boxstyle": "round,pad=0.28",
            "fc": "white",
            "ec": "#D5D5D5",
            "alpha": 0.96,
        },
    )

    fig.text(
        0.5,
        0.045,
        f"High Trust 리뷰 유지율: {row['retention_rate']:.1%} "
        f"({counts[1]:,}/{counts[0]:,}개)",
        ha="center",
        va="center",
        fontsize=11.5,
        color="#555555",
    )
    fig.tight_layout(rect=[0, 0.08, 1, 1])
    fig.savefig(
        OUTPUT_DIR / "fig_overall_vs_hightrust_avg_score.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def save_store_dumbbell_figure(eligible):
    plot_df = (
        eligible.nlargest(TOP_N_LARGEST, "abs_change")
        .sort_values("score_change")
        .reset_index(drop=True)
    )
    y = np.arange(len(plot_df))
    fig_height = max(7.5, len(plot_df) * 0.48 + 2.5)
    fig, ax = plt.subplots(figsize=(11.8, fig_height + 0.3))

    for idx, row in plot_df.iterrows():
        ax.plot(
            [row["score_before"], row["score_after"]],
            [idx, idx],
            color="#B5B5B5",
            linewidth=2.2,
            zorder=1,
        )
    ax.scatter(
        plot_df["score_before"],
        y,
        color=BEFORE_COLOR,
        s=72,
        edgecolor="#333333",
        linewidth=0.5,
        label="전체 리뷰",
        zorder=3,
    )
    ax.scatter(
        plot_df["score_after"],
        y,
        color=AFTER_COLOR,
        s=72,
        edgecolor="#333333",
        linewidth=0.5,
        label="High Trust",
        zorder=3,
    )
    for idx, row in plot_df.iterrows():
        right = max(row["score_before"], row["score_after"])
        ax.text(
            min(5.08, right + 0.07),
            idx,
            f"{row['score_change']:+.2f}",
            va="center",
            fontsize=11,
        )

    ax.set_yticks(y)
    ax.set_yticklabels(plot_df["store_name"], fontsize=11.5)
    ax.set_xlim(1, 5.35)
    ax.set_xlabel("평균 감성 별점", fontsize=12.5)
    ax.tick_params(axis="x", labelsize=11.5)
    ax.set_title(
        "식당별 감성 별점 변화: 전체 리뷰 vs High Trust 리뷰",
        fontsize=18,
        fontweight="bold",
        pad=19,
    )
    ax.text(
        0,
        1.012,
        f"변화 폭 상위 {len(plot_df)}개 식당 · 전체/High Trust 리뷰 각각 3개 이상",
        transform=ax.transAxes,
        fontsize=11,
        color="#555555",
    )
    ax.grid(axis="x", linestyle="--", alpha=0.28)
    ax.legend(loc="upper left", fontsize=11.5, markerscale=1.1)
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "fig_store_score_change_before_after.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def save_top5_figure(top_increase, top_decrease):
    plot_df = pd.concat([top_decrease, top_increase], ignore_index=True)
    plot_df = plot_df.sort_values("score_change").reset_index(drop=True)
    colors = [
        INCREASE_COLOR if value > 0 else DECREASE_COLOR
        for value in plot_df["score_change"]
    ]
    fig, ax = plt.subplots(figsize=(11.2, 7.5))
    y = np.arange(len(plot_df))
    bars = ax.barh(y, plot_df["score_change"], color=colors)
    ax.axvline(0, color="#333333", linewidth=1)
    ax.set_yticks(y)
    ax.set_yticklabels(plot_df["store_name"], fontsize=12)
    ax.set_xlabel("점수 변화 (High Trust - 전체 리뷰)", fontsize=12.5)
    ax.tick_params(axis="x", labelsize=11.5)
    ax.set_title(
        "High Trust 필터 적용 후 주요 점수 변화 식당",
        fontsize=19,
        fontweight="bold",
        pad=16,
    )
    ax.grid(axis="x", linestyle="--", alpha=0.25)
    for bar, value in zip(bars, plot_df["score_change"]):
        if value >= 0:
            text_x = value + 0.015
            horizontal_alignment = "left"
            text_color = "#111111"
        elif abs(value) >= 0.05:
            # 큰 하락은 막대 내부에 흰 글씨로 표시해 식당명과 겹치지 않게 합니다.
            text_x = value + 0.012
            horizontal_alignment = "left"
            text_color = "white"
        else:
            text_x = value - 0.012
            horizontal_alignment = "right"
            text_color = "#111111"
        ax.text(
            text_x,
            bar.get_y() + bar.get_height() / 2,
            f"{value:+.3f}",
            va="center",
            ha=horizontal_alignment,
            fontweight="bold",
            fontsize=12,
            color=text_color,
        )
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "fig_top5_score_increase_decrease.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def save_largest_change_figure(largest):
    plot_df = largest.sort_values("abs_change").reset_index(drop=True)
    colors = [
        INCREASE_COLOR if value > 0 else DECREASE_COLOR
        for value in plot_df["score_change"]
    ]
    fig, ax = plt.subplots(figsize=(10.5, 8))
    y = np.arange(len(plot_df))
    bars = ax.barh(y, plot_df["abs_change"], color=colors)
    ax.set_yticks(y)
    ax.set_yticklabels(plot_df["store_name"])
    ax.set_xlabel("절대 점수 변화 폭")
    ax.set_title(
        "High Trust 필터 적용 후 변화 폭이 큰 식당",
        fontsize=17,
        fontweight="bold",
        pad=16,
    )
    ax.grid(axis="x", linestyle="--", alpha=0.25)
    for bar, signed_change in zip(bars, plot_df["score_change"]):
        ax.text(
            bar.get_width() + 0.01,
            bar.get_y() + bar.get_height() / 2,
            f"{signed_change:+.3f}",
            va="center",
            fontsize=9,
            fontweight="bold",
        )
    ax.text(
        0.01,
        1.01,
        "초록색: 상승 · 빨간색: 하락",
        transform=ax.transAxes,
        fontsize=9.5,
        color="#555555",
    )
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "fig_largest_score_change_stores.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def save_platform_figure(platform_summary):
    if platform_summary.empty:
        return
    plot_df = platform_summary.sort_values("platform").reset_index(drop=True)
    x = np.arange(len(plot_df))
    width = 0.34
    fig, ax = plt.subplots(figsize=(9.5, 6))
    before_bars = ax.bar(
        x - width / 2,
        plot_df["score_before"],
        width,
        color=BEFORE_COLOR,
        label="전체 리뷰",
    )
    after_bars = ax.bar(
        x + width / 2,
        plot_df["score_after"],
        width,
        color=AFTER_COLOR,
        label="High Trust",
    )
    ax.set_xticks(x)
    ax.set_xticklabels(plot_df["platform"])
    ax.set_ylim(0, 5.35)
    ax.set_ylabel("평균 감성 별점")
    ax.set_title(
        "플랫폼별 High Trust 필터 적용 전후 감성 별점 변화",
        fontsize=16,
        fontweight="bold",
        pad=16,
    )
    ax.grid(axis="y", linestyle="--", alpha=0.28)
    ax.legend()
    for bars in [before_bars, after_bars]:
        for bar in bars:
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.07,
                f"{bar.get_height():.3f}",
                ha="center",
                va="bottom",
                fontsize=9,
                fontweight="bold",
            )
    for idx, row in plot_df.iterrows():
        ax.text(
            idx,
            0.22,
            f"변화 {row['score_change']:+.3f}\n유지율 {row['retention_rate']:.1%}",
            ha="center",
            fontsize=9,
            bbox={"boxstyle": "round,pad=0.3", "fc": "#F5F5F5", "ec": "#BBBBBB"},
        )
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "fig_platform_before_after_hightrust.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def save_aspect_figure(aspect_summary):
    if aspect_summary.empty:
        return
    matrix = aspect_summary.set_index("aspect")[
        ["score_before", "score_after", "score_change"]
    ]
    max_abs = max(0.25, float(np.nanmax(np.abs(matrix.values))))
    norm = TwoSlopeNorm(vmin=-max_abs, vcenter=0, vmax=max_abs)
    fig, ax = plt.subplots(figsize=(9.5, 7))
    image = ax.imshow(matrix.values, cmap="RdYlGn", norm=norm, aspect="auto")
    ax.set_xticks(np.arange(3))
    ax.set_xticklabels(["전체 리뷰", "High Trust", "변화\n(High Trust-전체)"])
    ax.set_yticks(np.arange(len(matrix.index)))
    ax.set_yticklabels(matrix.index)
    ax.set_title(
        "High Trust 필터 적용 전후 카테고리 감성 변화",
        fontsize=17,
        fontweight="bold",
        pad=16,
    )
    for row in range(matrix.shape[0]):
        for column in range(matrix.shape[1]):
            value = matrix.iloc[row, column]
            ax.text(
                column,
                row,
                f"{value:+.3f}",
                ha="center",
                va="center",
                fontweight="bold" if column == 2 else "normal",
            )
    colorbar = fig.colorbar(image, ax=ax, shrink=0.82)
    colorbar.set_label("평균 aspect 점수")
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "fig_aspect_before_after_hightrust.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def build_interpretation(overall, eligible, store_change_summary):
    row = overall.iloc[0]
    summary = store_change_summary.iloc[0]
    increase = eligible.nlargest(3, "score_change")
    decrease = eligible.nsmallest(3, "score_change")

    increase_text = ", ".join(
        f"{item.store_name}({item.score_change:+.3f}점)"
        for item in increase.itertuples()
    )
    decrease_text = ", ".join(
        f"{item.store_name}({item.score_change:+.3f}점)"
        for item in decrease.itertuples()
    )
    overall_direction = "상승" if row["score_change"] > 0 else "하락"
    store_direction = (
        "상승"
        if summary["mean_store_score_change"] > 0
        else "하락"
    )

    return [
        (
            f"전체 리뷰 기준 평균 감성 별점은 {row['score_before']:.3f}점이었고, "
            f"High Trust 리뷰 기준 평균은 {row['score_after']:.3f}점으로 "
            f"{abs(row['score_change']):.3f}점 {overall_direction}했다."
        ),
        (
            f"전체 리뷰 {int(row['all_review_count']):,}개 중 "
            f"{int(row['high_trust_review_count']):,}개가 High Trust로 유지되어 "
            f"리뷰 유지율은 {row['retention_rate']:.1%}였다."
        ),
        (
            f"발표 기준을 만족한 {len(eligible)}개 식당 중 "
            f"{int(summary['increase_store_count'])}개는 상승하고 "
            f"{int(summary['decrease_store_count'])}개는 하락했으며, 식당별 평균 변화는 "
            f"{abs(summary['mean_store_score_change']):.3f}점 {store_direction}했다"
            f"(bootstrap 95% 구간: {summary['bootstrap_ci95_low']:+.3f}~"
            f"{summary['bootstrap_ci95_high']:+.3f})."
        ),
        f"상승 폭이 큰 식당은 {increase_text}이며, 하락 폭이 큰 식당은 {decrease_text}이다.",
        (
            "따라서 High Trust 필터는 리뷰 수를 줄이는 것뿐 아니라 일부 식당의 평가 점수를 "
            "재구성하는 효과를 보였다. 다만 점수 변화의 원인을 신뢰도 필터 자체로 단정하려면 "
            "제거된 리뷰의 내용과 플랫폼 구성 차이를 추가로 분석해야 한다."
        ),
    ]


def main():
    for path in [ALL_REVIEWS_FILE, HIGH_TRUST_FILE]:
        if not path.exists():
            raise FileNotFoundError(f"입력 파일을 찾을 수 없습니다: {path}")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    selected_font = configure_korean_font()
    all_raw, all_encoding = read_csv_safely(ALL_REVIEWS_FILE)
    high_raw, high_encoding = read_csv_safely(HIGH_TRUST_FILE)
    all_df = clean_frame(all_raw)
    high_df = clean_frame(high_raw)

    overall = build_overall_summary(all_df, high_df)
    store_changes = build_store_change(all_df, high_df)
    eligible = store_changes.loc[store_changes["eligible_for_presentation"]].copy()
    store_change_summary = bootstrap_store_change_summary(eligible)

    top_increase = (
        eligible.loc[eligible["score_change"] > 0]
        .nlargest(TOP_N_INCREASE_DECREASE, "score_change")
    )
    top_decrease = (
        eligible.loc[eligible["score_change"] < 0]
        .nsmallest(TOP_N_INCREASE_DECREASE, "score_change")
    )
    largest = eligible.nlargest(TOP_N_LARGEST, "abs_change")
    platform_summary = build_platform_summary(all_df, high_df)
    aspect_summary = build_aspect_summary(all_df, high_df)

    overall.to_csv(
        OUTPUT_DIR / "summary_overall_vs_hightrust.csv",
        index=False,
        encoding="utf-8-sig",
    )
    store_changes.to_csv(
        OUTPUT_DIR / "store_score_change_overall_vs_hightrust.csv",
        index=False,
        encoding="utf-8-sig",
    )
    eligible.to_csv(
        OUTPUT_DIR / "store_score_change_presentation_filtered.csv",
        index=False,
        encoding="utf-8-sig",
    )
    store_change_summary.to_csv(
        OUTPUT_DIR / "store_score_change_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    top_increase.to_csv(
        OUTPUT_DIR / "top5_score_increase.csv",
        index=False,
        encoding="utf-8-sig",
    )
    top_decrease.to_csv(
        OUTPUT_DIR / "top5_score_decrease.csv",
        index=False,
        encoding="utf-8-sig",
    )
    largest.to_csv(
        OUTPUT_DIR / "largest_score_change_stores.csv",
        index=False,
        encoding="utf-8-sig",
    )
    if not platform_summary.empty:
        platform_summary.to_csv(
            OUTPUT_DIR / "platform_before_after_hightrust.csv",
            index=False,
            encoding="utf-8-sig",
        )
    if not aspect_summary.empty:
        aspect_summary.to_csv(
            OUTPUT_DIR / "aspect_before_after_hightrust.csv",
            index=False,
            encoding="utf-8-sig",
        )

    save_overall_figure(overall)
    save_store_dumbbell_figure(eligible)
    save_top5_figure(top_increase, top_decrease)
    save_largest_change_figure(largest)
    save_platform_figure(platform_summary)
    save_aspect_figure(aspect_summary)

    interpretation = build_interpretation(overall, eligible, store_change_summary)
    (OUTPUT_DIR / "hightrust_score_change_interpretation.txt").write_text(
        "\n\n".join(interpretation) + "\n",
        encoding="utf-8",
    )

    limitation_lines = [
        "분석 기준 및 한계",
        "",
        f"- 발표용 식당 기준: 전체 리뷰 {MIN_ALL_REVIEWS}개 이상, High Trust 리뷰 {MIN_HIGH_TRUST_REVIEWS}개 이상",
        "- 전체 평균은 리뷰 단위 평균이므로 리뷰 수가 많은 식당의 영향이 큽니다.",
        "- 식당별 평균 변화는 식당마다 동일한 비중을 주어 별도로 계산했습니다.",
        "- High Trust 결과는 전체 리뷰의 부분집합이며, CSV 행은 제공된 형태 그대로 사용했습니다.",
        "- 필터 후 점수 변화는 확인할 수 있지만 변화 원인을 필터 자체로 단정할 수는 없습니다.",
        "- 제거된 리뷰의 플랫폼, 작성 시점, 표현 방식 차이가 결과에 영향을 줄 수 있습니다.",
    ]
    (OUTPUT_DIR / "hightrust_score_change_method_limitations.txt").write_text(
        "\n".join(limitation_lines) + "\n",
        encoding="utf-8",
    )

    print(f"[전체 리뷰 인코딩] {all_encoding}")
    print(f"[High Trust 인코딩] {high_encoding}")
    print(f"[한글 폰트] {selected_font}")
    print(f"[전체 리뷰 수] {len(all_df):,}")
    print(f"[High Trust 리뷰 수] {len(high_df):,}")
    print(f"[발표 기준 충족 식당 수] {len(eligible):,}")
    print("\n[전체 요약]")
    print(overall.to_string(index=False))
    print("\n[식당 변화 요약]")
    print(store_change_summary.to_string(index=False))
    print("\n[발표용 해석]")
    for line in interpretation:
        print(f"- {line}")
    print(f"\n[산출물 폴더] {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
