from __future__ import annotations

from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.patches import Rectangle, FancyBboxPatch


SCRIPT_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = SCRIPT_DIR

ENCODINGS = ("utf-8-sig", "cp949", "utf-8", "euc-kr")
MIN_PLATFORM_REVIEWS = 5
MAX_STORES = 8
MIN_EVIDENCE_COUNT = 3
MIN_EVIDENCE_RATE = 0.05
CHECK_SCORE_THRESHOLD = -0.03
STRENGTH_SCORE_THRESHOLD = 0.05

STORE_CANDIDATES = ["store_name", "restaurant_name", "가게명", "식당명"]
PLATFORM_CANDIDATES = ["platform", "source", "플랫폼"]
SENTIMENT_CANDIDATES = ["sentiment_star", "text_sentiment_star", "감성별점", "텍스트감성점수"]

ASPECT_CANDIDATES = {
    "food": ["food_score", "food", "음식", "맛"],
    "price": ["price_score", "price", "가격", "가성비"],
    "service": ["service_score", "service", "서비스", "응대"],
    "atmosphere": ["atmosphere_score", "atmosphere", "분위기"],
    "wait": ["wait_score", "waiting_score", "wait", "웨이팅", "대기"],
    "revisit": ["revisit_score", "revisit", "재방문", "추천"],
    "hygiene": ["hygiene_score", "hygiene", "위생", "청결"],
}

ASPECT_LABELS = {
    "food": "음식",
    "price": "가격",
    "service": "서비스",
    "atmosphere": "분위기",
    "wait": "웨이팅",
    "revisit": "재방문",
    "hygiene": "위생",
}

PLATFORM_LABELS = {
    "naver": "네이버",
    "kakao": "카카오",
}


def set_korean_font() -> None:
    plt.rcParams["font.family"] = ["Malgun Gothic", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["figure.facecolor"] = "white"
    plt.rcParams["axes.facecolor"] = "white"


def read_csv_safely(path: Path) -> tuple[pd.DataFrame, str]:
    last_error: Exception | None = None
    for enc in ENCODINGS:
        try:
            return pd.read_csv(path, encoding=enc, low_memory=False), enc
        except Exception as exc:  # noqa: BLE001
            last_error = exc
    raise RuntimeError(f"CSV 읽기 실패: {path} ({last_error})")


def norm_col(name: str) -> str:
    return str(name).strip().lower().replace(" ", "").replace("_", "")


def find_column(columns: Iterable[str], candidates: list[str], required: bool = True) -> str | None:
    columns = list(columns)
    norm_map = {norm_col(col): col for col in columns}
    for cand in candidates:
        key = norm_col(cand)
        if key in norm_map:
            return norm_map[key]
    for cand in candidates:
        key = norm_col(cand)
        for col in columns:
            if key and key in norm_col(col):
                return col
    if required:
        raise KeyError(f"컬럼을 찾지 못했습니다. 후보: {candidates}")
    return None


def normalize_platform(value: object) -> str:
    text = str(value).strip().lower()
    if "naver" in text or "네이버" in text:
        return "naver"
    if "kakao" in text or "카카오" in text:
        return "kakao"
    return text


def find_input_file() -> tuple[Path, pd.DataFrame, str, dict[str, str]]:
    priority = [
        "final_high_trust_reviews_sentiment_star_positive_recovery_review_view.csv",
        "final_high_trust_reviews_sentiment_star_minimal_tuned_review_view.csv",
        "final_high_trust_reviews_sentiment_star_final_tuned_review_view.csv",
        "final_high_trust_reviews_sentiment_star_overcap_review_view.csv",
    ]
    search_dirs = [
        SCRIPT_DIR,
        Path(r"C:\Users\eunse\OneDrive\바탕 화면\CSV 파일 합친거"),
    ]
    files: list[Path] = []
    for directory in search_dirs:
        if not directory.exists():
            continue
        for name in priority:
            candidate = directory / name
            if candidate.exists():
                files.append(candidate)
        files.extend(sorted(directory.glob("*.csv")))

    best: tuple[int, Path, pd.DataFrame, str, dict[str, str]] | None = None
    seen: set[Path] = set()
    for path in files:
        path = path.resolve()
        if path in seen:
            continue
        seen.add(path)
        try:
            df, enc = read_csv_safely(path)
            store_col = find_column(df.columns, STORE_CANDIDATES, required=False)
            platform_col = find_column(df.columns, PLATFORM_CANDIDATES, required=False)
            sentiment_col = find_column(df.columns, SENTIMENT_CANDIDATES, required=False)
            aspect_cols = {
                aspect: find_column(df.columns, candidates, required=False)
                for aspect, candidates in ASPECT_CANDIDATES.items()
            }
            matched_aspects = {k: v for k, v in aspect_cols.items() if v is not None}
            score = len(matched_aspects) * 10
            score += 30 if path.name in priority else 0
            score += 10 if store_col else 0
            score += 10 if platform_col else 0
            score += 10 if sentiment_col else 0
            if store_col and platform_col and sentiment_col and len(matched_aspects) >= 4:
                mapping = {
                    "store": store_col,
                    "platform": platform_col,
                    "sentiment": sentiment_col,
                    **{f"aspect_{k}": v for k, v in matched_aspects.items()},
                }
                if best is None or score > best[0]:
                    best = (score, path, df, enc, mapping)
        except Exception as exc:  # noqa: BLE001
            print(f"[건너뜀] {path.name}: {exc}")

    if best is None:
        raise FileNotFoundError("식당명, 플랫폼, 감성 점수, aspect 점수 컬럼을 가진 CSV를 찾지 못했습니다.")
    _, path, df, enc, mapping = best
    return path, df, enc, mapping


def prepare_data(df: pd.DataFrame, mapping: dict[str, str]) -> tuple[pd.DataFrame, list[str]]:
    aspect_keys = [a for a in ASPECT_LABELS if f"aspect_{a}" in mapping]
    cols = [mapping["store"], mapping["platform"], mapping["sentiment"]] + [mapping[f"aspect_{a}"] for a in aspect_keys]
    work = df[cols].copy()
    work = work.rename(
        columns={
            mapping["store"]: "store_name",
            mapping["platform"]: "platform",
            mapping["sentiment"]: "sentiment_star",
            **{mapping[f"aspect_{a}"]: a for a in aspect_keys},
        }
    )
    work["store_name"] = work["store_name"].astype(str).str.strip()
    work["platform"] = work["platform"].map(normalize_platform)
    work = work[work["platform"].isin(["naver", "kakao"])]
    work = work[work["store_name"].ne("")]
    work["sentiment_star"] = pd.to_numeric(work["sentiment_star"], errors="coerce")
    for aspect in aspect_keys:
        work[aspect] = pd.to_numeric(work[aspect], errors="coerce")
    work = work.dropna(subset=["store_name", "platform", "sentiment_star"])
    return work, aspect_keys


def build_platform_summary(work: pd.DataFrame, aspect_keys: list[str]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    sent = (
        work.groupby(["store_name", "platform"])
        .agg(review_count=("sentiment_star", "size"), mean_sentiment=("sentiment_star", "mean"))
        .reset_index()
    )
    sent_pivot = sent.pivot(index="store_name", columns="platform", values="mean_sentiment")
    count_pivot = sent.pivot(index="store_name", columns="platform", values="review_count")
    paired = pd.DataFrame(index=sent_pivot.index)
    paired["naver_mean_sentiment"] = sent_pivot.get("naver")
    paired["kakao_mean_sentiment"] = sent_pivot.get("kakao")
    paired["naver_review_count"] = count_pivot.get("naver")
    paired["kakao_review_count"] = count_pivot.get("kakao")
    paired = paired.dropna(subset=["naver_mean_sentiment", "kakao_mean_sentiment", "naver_review_count", "kakao_review_count"])
    paired = paired[
        (paired["naver_review_count"] >= MIN_PLATFORM_REVIEWS)
        & (paired["kakao_review_count"] >= MIN_PLATFORM_REVIEWS)
    ].copy()
    paired["platform_gap"] = paired["naver_mean_sentiment"] - paired["kakao_mean_sentiment"]
    paired["platform_gap_abs"] = paired["platform_gap"].abs()
    paired = paired.sort_values("platform_gap_abs", ascending=False)

    rows = []
    for (store, platform), group in work.groupby(["store_name", "platform"]):
        review_count = len(group)
        for aspect in aspect_keys:
            score = group[aspect]
            evidence_count = int((score.fillna(0) != 0).sum())
            evidence_rate = evidence_count / review_count if review_count else np.nan
            rows.append(
                {
                    "store_name": store,
                    "platform": platform,
                    "aspect": aspect,
                    "aspect_label": ASPECT_LABELS[aspect],
                    "review_count": review_count,
                    "aspect_score_mean": float(score.mean()),
                    "aspect_evidence_count": evidence_count,
                    "aspect_evidence_rate": evidence_rate,
                    "enough_evidence": evidence_count >= MIN_EVIDENCE_COUNT and evidence_rate >= MIN_EVIDENCE_RATE,
                }
            )
    aspect_long = pd.DataFrame(rows)
    aspect_long["is_check_candidate"] = (
        (aspect_long["aspect_score_mean"] <= CHECK_SCORE_THRESHOLD)
        & aspect_long["enough_evidence"]
    )
    aspect_long["is_strength"] = (
        (aspect_long["aspect_score_mean"] >= STRENGTH_SCORE_THRESHOLD)
        & aspect_long["enough_evidence"]
    )
    return paired, sent, aspect_long


def select_stores(paired: pd.DataFrame, max_stores: int = MAX_STORES) -> pd.DataFrame:
    return paired.head(max_stores).reset_index()


def aspect_matrix(aspect_long: pd.DataFrame, stores: list[str], platform: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    sub = aspect_long[(aspect_long["store_name"].isin(stores)) & (aspect_long["platform"] == platform)].copy()
    sub["store_name"] = pd.Categorical(sub["store_name"], categories=stores, ordered=True)
    matrix = sub.pivot(index="store_name", columns="aspect_label", values="aspect_score_mean")
    enough = sub.pivot(index="store_name", columns="aspect_label", values="enough_evidence")
    ordered_cols = [ASPECT_LABELS[a] for a in ASPECT_LABELS if ASPECT_LABELS[a] in matrix.columns]
    return matrix[ordered_cols], enough[ordered_cols].astype(bool)


def add_heatmap_labels(ax: plt.Axes, matrix: pd.DataFrame, enough: pd.DataFrame, strong_threshold: float = 1.35) -> None:
    for y in range(matrix.shape[0]):
        for x in range(matrix.shape[1]):
            value = float(matrix.iloc[y, x])
            ok = bool(enough.iloc[y, x])
            label = f"{value:.2f}" + ("" if ok else "*")
            if not ok:
                ax.add_patch(
                    Rectangle((x - 0.5, y - 0.5), 1, 1, fill=False, hatch="///", linewidth=0, edgecolor="#9ca3af", alpha=0.22)
                )
            color = "white" if value >= strong_threshold and ok else "#1f2937"
            if value <= -0.08 and ok:
                color = "#9a3412"
            if not ok:
                color = "#6b7280"
            ax.text(x, y, label, ha="center", va="center", fontsize=12.1, fontweight="bold", color=color)


def style_heatmap_axis(ax: plt.Axes, matrix: pd.DataFrame, row_labels: list[str] | None = None) -> None:
    ax.set_xticks(np.arange(matrix.shape[1]))
    ax.set_xticklabels(matrix.columns, fontsize=14.0, fontweight="bold")
    ax.set_yticks(np.arange(matrix.shape[0]))
    ax.set_yticklabels(row_labels if row_labels else matrix.index, fontsize=12.0, fontweight="bold")
    ax.set_xticks(np.arange(-0.5, matrix.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, matrix.shape[0], 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=2.0)
    ax.tick_params(which="minor", bottom=False, left=False)
    ax.tick_params(axis="both", length=0)


def add_split_row_labels(ax: plt.Axes, selected: pd.DataFrame) -> None:
    """Draw restaurant names large and N/K/gap metadata smaller for slide readability."""
    for y, row in enumerate(selected.itertuples(index=False)):
        ax.text(
            -0.010,
            y - 0.15,
            str(row.store_name),
            transform=ax.get_yaxis_transform(),
            ha="right",
            va="center",
            fontsize=13.6,
            fontweight="bold",
            color="#111827",
            clip_on=False,
        )
        ax.text(
            -0.010,
            y + 0.20,
            f"N={int(row.naver_review_count)} / K={int(row.kakao_review_count)} / gap={row.platform_gap:+.2f}",
            transform=ax.get_yaxis_transform(),
            ha="right",
            va="center",
            fontsize=10.5,
            fontweight="bold",
            color="#111827",
            clip_on=False,
        )


def draw_side_by_side_heatmap(
    naver_matrix: pd.DataFrame,
    kakao_matrix: pd.DataFrame,
    naver_enough: pd.DataFrame,
    kakao_enough: pd.DataFrame,
    selected: pd.DataFrame,
    output_path: Path,
) -> None:
    set_korean_font()
    fig = plt.figure(figsize=(22.5, 11.4), dpi=150)
    gs = fig.add_gridspec(1, 3, width_ratios=[1, 1, 0.045], wspace=0.065)
    ax_n = fig.add_subplot(gs[0, 0])
    ax_k = fig.add_subplot(gs[0, 1])
    cax = fig.add_subplot(gs[0, 2])

    cmap = LinearSegmentedColormap.from_list(
        "platform_aspect",
        ["#c2410c", "#f4a261", "#f7f7f4", "#9bd5cf", "#008891", "#064e63"],
    )
    combined = np.r_[naver_matrix.values.ravel(), kakao_matrix.values.ravel()]
    vmin = min(-0.35, float(np.nanmin(combined)))
    vmax = max(2.55, float(np.nanmax(combined)))
    norm = TwoSlopeNorm(vmin=vmin, vcenter=0, vmax=vmax)

    im = ax_n.imshow(naver_matrix.values, cmap=cmap, norm=norm, aspect="auto")
    ax_k.imshow(kakao_matrix.values, cmap=cmap, norm=norm, aspect="auto")

    row_labels = [""] * len(selected)
    style_heatmap_axis(ax_n, naver_matrix, row_labels=row_labels)
    style_heatmap_axis(ax_k, kakao_matrix, row_labels=row_labels)
    add_split_row_labels(ax_n, selected)
    add_heatmap_labels(ax_n, naver_matrix, naver_enough)
    add_heatmap_labels(ax_k, kakao_matrix, kakao_enough)
    ax_n.set_title("네이버", fontsize=22, fontweight="bold", color="#1f7a3a", pad=18)
    ax_k.set_title("카카오", fontsize=22, fontweight="bold", color="#b77900", pad=18)

    cbar = fig.colorbar(im, cax=cax)
    cbar.ax.set_title("점수", fontsize=13, fontweight="bold", pad=9)
    cbar.set_ticks([vmin, 0, vmax])
    cbar.set_ticklabels(["낮음\n점검 후보", "중립", "높음\n강점"])
    cbar.ax.tick_params(labelsize=11.0)

    fig.text(0.5, 0.965, "플랫폼별 Aspect 반응 비교: 네이버와 카카오의 차이", ha="center", va="top", fontsize=27, fontweight="bold")
    fig.text(
        0.5,
        0.925,
        "같은 식당이라도 플랫폼별로 강하게 나타나는 aspect와 점검 후보가 다르게 나타날 수 있습니다.",
        ha="center",
        va="top",
        fontsize=14.5,
        color="#5f6368",
    )
    fig.text(
        0.5,
        0.035,
        "* 또는 해칭 셀 = evidence 부족으로 판단 유보. 낮은 점수는 바로 약점이 아니라, 리뷰에서 충분히 언급된 경우에만 점검 후보로 보았습니다.",
        ha="center",
        va="bottom",
        fontsize=12.5,
        color="#666666",
    )
    fig.subplots_adjust(left=0.19, right=0.94, top=0.835, bottom=0.11)
    fig.savefig(output_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def draw_gap_heatmap(
    naver_matrix: pd.DataFrame,
    kakao_matrix: pd.DataFrame,
    naver_enough: pd.DataFrame,
    kakao_enough: pd.DataFrame,
    selected: pd.DataFrame,
    output_path: Path,
) -> None:
    set_korean_font()
    gap = naver_matrix - kakao_matrix
    enough = naver_enough & kakao_enough

    fig = plt.figure(figsize=(17.2, 9.8), dpi=150)
    gs = fig.add_gridspec(1, 2, width_ratios=[5.4, 1.25], wspace=0.08)
    ax = fig.add_subplot(gs[0, 0])
    side = fig.add_subplot(gs[0, 1])
    side.axis("off")

    cmap = LinearSegmentedColormap.from_list(
        "platform_gap",
        ["#b45309", "#f6ad55", "#f7f7f4", "#8fd0c9", "#008891", "#055160"],
    )
    lim = max(0.45, float(np.nanmax(np.abs(gap.values))))
    norm = TwoSlopeNorm(vmin=-lim, vcenter=0, vmax=lim)
    im = ax.imshow(gap.values, cmap=cmap, norm=norm, aspect="auto")

    row_labels = [
        f"{row.store_name}  ({row.platform_gap:+.2f})"
        for row in selected.itertuples(index=False)
    ]
    style_heatmap_axis(ax, gap, row_labels=row_labels)

    for y in range(gap.shape[0]):
        for x in range(gap.shape[1]):
            value = float(gap.iloc[y, x])
            ok = bool(enough.iloc[y, x])
            label = f"{value:+.2f}" + ("" if ok else "*")
            if not ok:
                ax.add_patch(Rectangle((x - 0.5, y - 0.5), 1, 1, fill=False, hatch="///", linewidth=0, edgecolor="#9ca3af", alpha=0.22))
            color = "white" if abs(value) >= lim * 0.62 and ok else "#1f2937"
            if not ok:
                color = "#6b7280"
            ax.text(x, y, label, ha="center", va="center", fontsize=9.4, fontweight="bold", color=color)

    cbar = fig.colorbar(im, ax=ax, fraction=0.026, pad=0.012)
    cbar.ax.set_title("N-K", fontsize=11.5, fontweight="bold", pad=8)
    cbar.set_ticks([-lim, 0, lim])
    cbar.set_ticklabels(["카카오\n높음", "차이 작음", "네이버\n높음"])
    cbar.ax.tick_params(labelsize=9.2)

    card = FancyBboxPatch((0.04, 0.16), 0.90, 0.70, boxstyle="round,pad=0.035,rounding_size=0.04", fc="#f8fbfd", ec="#d7e0e7", lw=1.7, transform=side.transAxes)
    side.add_patch(card)
    side.text(0.12, 0.78, "읽는 법", transform=side.transAxes, fontsize=19, fontweight="bold", color="#073b4c")
    side.text(0.12, 0.63, "양수\n= 네이버에서 더 긍정", transform=side.transAxes, fontsize=13.8, fontweight="bold", color="#075985", linespacing=1.45)
    side.text(0.12, 0.45, "음수\n= 카카오에서 더 긍정", transform=side.transAxes, fontsize=13.8, fontweight="bold", color="#9a3412", linespacing=1.45)
    side.text(0.12, 0.27, "* 해칭 셀\n= evidence 부족,\n  판단 유보", transform=side.transAxes, fontsize=12.5, fontweight="bold", color="#4b5563", linespacing=1.4)

    fig.text(0.5, 0.965, "네이버-카카오 Aspect 차이 히트맵", ha="center", va="top", fontsize=24.5, fontweight="bold")
    fig.text(
        0.5,
        0.925,
        "값은 네이버 aspect 점수 - 카카오 aspect 점수입니다.",
        ha="center",
        va="top",
        fontsize=13,
        color="#5f6368",
    )
    fig.text(
        0.5,
        0.035,
        "낮은 점수는 바로 약점이 아니라, 리뷰에서 충분히 언급된 경우에만 점검 후보로 보았습니다.",
        ha="center",
        va="bottom",
        fontsize=11.5,
        color="#666666",
    )
    fig.subplots_adjust(left=0.17, right=0.965, top=0.84, bottom=0.105, wspace=0.08)
    fig.savefig(output_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def choose_strength(row: pd.DataFrame) -> tuple[str, float, float]:
    pool = row[(row["is_strength"])].sort_values("aspect_score_mean", ascending=False)
    if pool.empty:
        pool = row.sort_values("aspect_score_mean", ascending=False)
    item = pool.iloc[0]
    return str(item["aspect_label"]), float(item["aspect_score_mean"]), float(item["aspect_evidence_rate"])


def choose_check(row: pd.DataFrame) -> tuple[str, float, float, bool]:
    pool = row[(row["is_check_candidate"])].sort_values("aspect_score_mean", ascending=True)
    if pool.empty:
        low = row.sort_values("aspect_score_mean", ascending=True).iloc[0]
        return str(low["aspect_label"]), float(low["aspect_score_mean"]), float(low["aspect_evidence_rate"]), False
    item = pool.iloc[0]
    return str(item["aspect_label"]), float(item["aspect_score_mean"]), float(item["aspect_evidence_rate"]), True


def build_summary(selected: pd.DataFrame, aspect_long: pd.DataFrame, aspect_keys: list[str]) -> pd.DataFrame:
    rows = []
    selected_names = selected["store_name"].tolist()
    for row in selected.itertuples(index=False):
        store = row.store_name
        naver_sub = aspect_long[(aspect_long["store_name"] == store) & (aspect_long["platform"] == "naver")]
        kakao_sub = aspect_long[(aspect_long["store_name"] == store) & (aspect_long["platform"] == "kakao")]
        n_strength, n_strength_score, n_strength_rate = choose_strength(naver_sub)
        k_check, k_check_score, k_check_rate, k_is_check = choose_check(kakao_sub)
        if k_is_check:
            check_label = f"{k_check} {k_check_score:+.2f}"
            interpretation = f"네이버는 {n_strength} 반응이 강하고, 카카오는 {k_check} 점검 신호가 확인됨"
            status = "우선 확인"
        elif k_check_rate < MIN_EVIDENCE_RATE:
            check_label = "판단 유보"
            interpretation = f"네이버는 {n_strength} 반응이 강하지만, 카카오의 낮은 항목은 evidence 부족"
            status = "근거 부족"
        else:
            check_label = f"{k_check} {k_check_score:+.2f}"
            interpretation = f"네이버는 {n_strength} 반응이 강하고, 카카오는 뚜렷한 점검 후보가 약함"
            status = "판단 유보"

        out = {
            "store_name": store,
            "naver_mean_sentiment": row.naver_mean_sentiment,
            "kakao_mean_sentiment": row.kakao_mean_sentiment,
            "platform_gap": row.platform_gap,
            "platform_gap_abs": row.platform_gap_abs,
            "naver_review_count": int(row.naver_review_count),
            "kakao_review_count": int(row.kakao_review_count),
            "naver_strong_aspect": n_strength,
            "naver_strong_score": n_strength_score,
            "naver_strong_evidence_rate": n_strength_rate,
            "kakao_check_aspect": k_check,
            "kakao_check_score": k_check_score,
            "kakao_check_evidence_rate": k_check_rate,
            "kakao_check_label": check_label,
            "kakao_check_status": status,
            "interpretation": interpretation,
        }
        for aspect in aspect_keys:
            for platform in ["naver", "kakao"]:
                v = aspect_long[(aspect_long["store_name"] == store) & (aspect_long["platform"] == platform) & (aspect_long["aspect"] == aspect)]
                if not v.empty:
                    out[f"{platform}_{aspect}_score"] = float(v["aspect_score_mean"].iloc[0])
                    out[f"{platform}_{aspect}_evidence_rate"] = float(v["aspect_evidence_rate"].iloc[0])
                    out[f"{platform}_{aspect}_evidence_count"] = int(v["aspect_evidence_count"].iloc[0])
        rows.append(out)
    return pd.DataFrame(rows)


def draw_summary_chart(summary: pd.DataFrame, output_path: Path) -> None:
    set_korean_font()
    n = len(summary)
    fig, ax = plt.subplots(figsize=(18.0, 10.2), dpi=150)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, n + 1.55)
    ax.axis("off")

    fig.text(0.5, 0.965, "플랫폼별 점수 차이가 큰 식당의 Aspect 차이 요약", ha="center", va="top", fontsize=24.5, fontweight="bold")
    fig.text(
        0.5,
        0.925,
        "네이버 평균 감성 점수와 카카오 평균 감성 점수 차이가 큰 식당을 대상으로 aspect 반응을 요약했습니다.",
        ha="center",
        va="top",
        fontsize=13,
        color="#666666",
    )

    xs = [0.03, 0.285, 0.42, 0.55, 0.70, 0.84]
    widths = [0.225, 0.10, 0.10, 0.12, 0.12, 0.125]
    headers = ["식당", "네이버", "카카오", "차이(N-K)", "네이버 강점", "카카오 점검"]
    for x, w, header in zip(xs, widths, headers):
        ax.add_patch(Rectangle((x, n + 0.62), w, 0.50, facecolor="#eef2f6", edgecolor="white"))
        ax.text(x + w / 2, n + 0.87, header, ha="center", va="center", fontsize=12.8, fontweight="bold")

    for i, row in summary.reset_index(drop=True).iterrows():
        y = n - i - 0.03
        bg = "#ffffff" if i % 2 == 0 else "#fafafa"
        ax.add_patch(Rectangle((0.02, y - 0.48), 0.955, 0.83, facecolor=bg, edgecolor="#e5e7eb", linewidth=0.85))
        ax.text(0.04, y - 0.08, f"{row['store_name']}\nN={row['naver_review_count']} / K={row['kakao_review_count']}", ha="left", va="center", fontsize=11.2, fontweight="bold", color="#111827", linespacing=1.35)
        ax.text(0.335, y - 0.08, f"{row['naver_mean_sentiment']:.3f}", ha="center", va="center", fontsize=12.4, fontweight="bold", color="#166534")
        ax.text(0.470, y - 0.08, f"{row['kakao_mean_sentiment']:.3f}", ha="center", va="center", fontsize=12.4, fontweight="bold", color="#a16207")

        gap_color = "#075985" if row["platform_gap"] >= 0 else "#9a3412"
        ax.add_patch(FancyBboxPatch((0.55, y - 0.31), 0.12, 0.46, boxstyle="round,pad=0.015,rounding_size=0.025", fc="#eef6fb" if row["platform_gap"] >= 0 else "#fff1e8", ec="#bfdbfe" if row["platform_gap"] >= 0 else "#f3c5a6"))
        ax.text(0.61, y - 0.08, f"{row['platform_gap']:+.3f}", ha="center", va="center", fontsize=12.1, fontweight="bold", color=gap_color)

        ax.add_patch(FancyBboxPatch((0.70, y - 0.34), 0.12, 0.52, boxstyle="round,pad=0.015,rounding_size=0.025", fc="#e4f4f1", ec="#acdcd4"))
        ax.text(0.76, y - 0.05, f"{row['naver_strong_aspect']} {row['naver_strong_score']:+.2f}", ha="center", va="center", fontsize=10.8, fontweight="bold", color="#006d77")
        ax.text(0.76, y - 0.27, f"evidence {row['naver_strong_evidence_rate']*100:.1f}%", ha="center", va="center", fontsize=8.9, color="#37716f")

        is_check = row["kakao_check_status"] == "우선 확인"
        fc = "#fff1e8" if is_check else "#f3f4f6"
        ec = "#f3c5a6" if is_check else "#d1d5db"
        color = "#ba3a1d" if is_check else "#4b5563"
        ax.add_patch(FancyBboxPatch((0.84, y - 0.34), 0.125, 0.52, boxstyle="round,pad=0.015,rounding_size=0.025", fc=fc, ec=ec))
        ax.text(0.9025, y - 0.05, row["kakao_check_label"], ha="center", va="center", fontsize=10.3, fontweight="bold", color=color)
        ax.text(0.9025, y - 0.27, f"evidence {row['kakao_check_evidence_rate']*100:.1f}%", ha="center", va="center", fontsize=8.9, color="#6b7280")

    fig.text(
        0.5,
        0.035,
        "낮은 점수는 바로 약점이 아니라, 리뷰에서 충분히 언급된 경우에만 점검 후보로 보았습니다.",
        ha="center",
        va="bottom",
        fontsize=11.5,
        color="#666666",
    )
    fig.subplots_adjust(left=0.02, right=0.985, top=0.86, bottom=0.08)
    fig.savefig(output_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def save_summary_csv(summary: pd.DataFrame, output_path: Path) -> None:
    summary.to_csv(output_path, index=False, encoding="utf-8-sig")


def main() -> None:
    input_path, df, enc, mapping = find_input_file()
    work, aspect_keys = prepare_data(df, mapping)
    paired, sent_summary, aspect_long = build_platform_summary(work, aspect_keys)
    selected = select_stores(paired, MAX_STORES)
    stores = selected["store_name"].tolist()

    naver_matrix, naver_enough = aspect_matrix(aspect_long, stores, "naver")
    kakao_matrix, kakao_enough = aspect_matrix(aspect_long, stores, "kakao")
    summary = build_summary(selected, aspect_long, aspect_keys)

    side_heatmap_path = OUTPUT_DIR / "fig_platform_aspect_heatmap_naver_kakao.png"
    gap_heatmap_path = OUTPUT_DIR / "fig_platform_aspect_gap_heatmap.png"
    summary_chart_path = OUTPUT_DIR / "fig_platform_gap_aspect_summary.png"
    summary_csv_path = OUTPUT_DIR / "summary_platform_aspect_gap.csv"

    draw_side_by_side_heatmap(naver_matrix, kakao_matrix, naver_enough, kakao_enough, selected, side_heatmap_path)
    draw_gap_heatmap(naver_matrix, kakao_matrix, naver_enough, kakao_enough, selected, gap_heatmap_path)
    draw_summary_chart(summary, summary_chart_path)
    save_summary_csv(summary, summary_csv_path)

    print("\n[사용 데이터]")
    print(f"- 파일명: {input_path}")
    print(f"- 인코딩: {enc}")
    print("\n[사용 컬럼]")
    print(f"- 식당명 컬럼: {mapping['store']}")
    print(f"- 플랫폼 컬럼: {mapping['platform']}")
    print(f"- 텍스트 감성 점수 컬럼: {mapping['sentiment']}")
    for aspect in aspect_keys:
        print(f"- {ASPECT_LABELS[aspect]}: {mapping[f'aspect_{aspect}']}")

    print("\n[식당 선정 기준]")
    print(f"- 네이버 High Trust 리뷰 수 >= {MIN_PLATFORM_REVIEWS}")
    print(f"- 카카오 High Trust 리뷰 수 >= {MIN_PLATFORM_REVIEWS}")
    print(f"- platform_gap_abs = |네이버 평균 감성 점수 - 카카오 평균 감성 점수| 상위 {MAX_STORES}개")

    print("\n[선정된 식당 및 플랫폼 점수 차이]")
    for row in selected.itertuples(index=False):
        print(
            f"- {row.store_name}: 네이버 {row.naver_mean_sentiment:.3f} "
            f"(n={int(row.naver_review_count)}), 카카오 {row.kakao_mean_sentiment:.3f} "
            f"(n={int(row.kakao_review_count)}), gap {row.platform_gap:+.3f}"
        )

    print("\n[evidence 계산 방식]")
    print("- 해당 식당·플랫폼·aspect에서 리뷰별 aspect_score가 0이 아니면 evidence가 탐지된 리뷰로 계산했습니다.")
    print(f"- 충분한 evidence 기준: evidence_count >= {MIN_EVIDENCE_COUNT} AND evidence_rate >= {MIN_EVIDENCE_RATE:.0%}")
    print(f"- 점검 후보 기준: aspect 평균 점수 <= {CHECK_SCORE_THRESHOLD:+.2f} AND 충분한 evidence")

    print("\n[생성된 그래프/CSV]")
    for path in [side_heatmap_path, gap_heatmap_path, summary_chart_path, summary_csv_path]:
        print(f"- {path.name}: {'저장 완료' if path.exists() else '저장 실패'}")

    print("\n[발표용 추천]")
    print("- 메인 추천: fig_platform_aspect_gap_heatmap.png")
    print("- 이유: 네이버-카카오 차이가 어느 aspect에서 벌어지는지 한 장에서 바로 읽을 수 있습니다.")
    print("- 보조 추천: fig_platform_gap_aspect_summary.png")
    print("- 이유: 식당별 평균 감성 차이와 네이버 강점/카카오 점검 후보를 발표 문장으로 연결하기 쉽습니다.")


if __name__ == "__main__":
    main()
