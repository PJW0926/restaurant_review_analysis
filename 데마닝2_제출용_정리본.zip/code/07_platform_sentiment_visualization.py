"""
네이버와 카카오의 맛집 리뷰 감성 별점을 비교하는 발표용 시각화 코드.

연구 질문:
    같은 식당이라도 네이버와 카카오에서 감성 별점이나 aspect 평가가
    다르게 나타나는가?

입력:
    final_high_trust_reviews_sentiment_star_positive_recovery_review_view.csv

출력:
    - platform_sentiment_summary.csv
    - store_naver_kakao_sentiment_comparison.csv
    - store_naver_kakao_sentiment_comparison_min_reviews.csv
    - paired_store_gap_summary.csv
    - aspect_platform_summary.csv
    - fig_platform_avg_sentiment_star.png
    - fig_store_naver_kakao_sentiment_comparison.png
    - fig_store_platform_gap.png
    - fig_aspect_platform_heatmap.png
    - presentation_interpretation.txt
"""

from pathlib import Path
import math
import sys

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import TwoSlopeNorm


INPUT_FILE = Path(
    r"C:\Users\eunse\OneDrive\바탕 화면\CSV 파일 합친거"
    r"\final_high_trust_reviews_sentiment_star_positive_recovery_review_view.csv"
)
OUTPUT_DIR = Path(__file__).resolve().parent

# 양쪽 플랫폼에서 각각 최소 이 수 이상의 리뷰가 있는 식당을 발표용 그래프에 사용합니다.
# 전체 식당 비교 결과는 별도 CSV에 모두 저장합니다.
MIN_REVIEWS_PER_PLATFORM = 5
TOP_N_GAP_STORES = 15

ASPECT_COLUMNS = [
    "food_score",
    "service_score",
    "price_score",
    "atmosphere_score",
    "wait_score",
    "revisit_score",
    "hygiene_score",
]

PLATFORM_COLORS = {
    "네이버": "#2DB400",
    "카카오": "#F5C400",
}


def read_csv_safely(path: Path):
    """지정된 인코딩 순서대로 CSV를 안전하게 읽습니다."""
    encodings = ["utf-8-sig", "utf-8", "cp949", "euc-kr"]
    last_error = None
    for encoding in encodings:
        try:
            return pd.read_csv(path, encoding=encoding), encoding
        except UnicodeDecodeError as error:
            last_error = error
    raise UnicodeDecodeError(
        "unknown",
        b"",
        0,
        1,
        f"CSV 인코딩을 읽지 못했습니다: {path} / 마지막 오류: {last_error}",
    )


def configure_korean_font():
    """Windows에서는 맑은 고딕을 우선 사용하고 마이너스 기호 깨짐을 방지합니다."""
    preferred_fonts = ["Malgun Gothic", "맑은 고딕", "AppleGothic", "NanumGothic"]
    installed = {font.name for font in font_manager.fontManager.ttflist}
    selected = next((font for font in preferred_fonts if font in installed), None)
    if selected:
        plt.rcParams["font.family"] = selected
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["figure.facecolor"] = "white"
    plt.rcParams["axes.facecolor"] = "white"
    return selected or "default"


def normalize_platform(value):
    """플랫폼명을 네이버/카카오로 통일합니다."""
    text = str(value).strip().lower()
    if text in {"naver", "네이버"}:
        return "네이버"
    if text in {"kakao", "카카오"}:
        return "카카오"
    return str(value).strip()


def sample_std(series):
    """리뷰가 1개일 때도 안전한 표준편차를 반환합니다."""
    return float(series.std(ddof=1)) if len(series) > 1 else 0.0


def build_platform_summary(df):
    records = []
    for platform, group in df.groupby("platform"):
        values = group["sentiment_star"].dropna()
        count = len(values)
        mean = float(values.mean())
        std = sample_std(values)
        standard_error = std / math.sqrt(count) if count else np.nan
        records.append(
            {
                "platform": platform,
                "review_count": count,
                "sentiment_star_mean": mean,
                "sentiment_star_std": std,
                "sentiment_star_median": float(values.median()),
                "standard_error": standard_error,
                "ci95_low": mean - 1.96 * standard_error,
                "ci95_high": mean + 1.96 * standard_error,
            }
        )
    return pd.DataFrame(records).sort_values("platform").reset_index(drop=True)


def build_store_comparison(df):
    grouped = (
        df.groupby(["store_name", "platform"])["sentiment_star"]
        .agg(["mean", "count", "std", "median"])
        .reset_index()
    )

    means = grouped.pivot(index="store_name", columns="platform", values="mean")
    counts = grouped.pivot(index="store_name", columns="platform", values="count")
    stds = grouped.pivot(index="store_name", columns="platform", values="std")
    medians = grouped.pivot(index="store_name", columns="platform", values="median")

    required = {"네이버", "카카오"}
    if not required.issubset(means.columns):
        raise ValueError("네이버와 카카오 양쪽 플랫폼 데이터가 모두 필요합니다.")

    comparison = pd.DataFrame(
        {
            "store_name": means.index,
            "naver_mean": means["네이버"],
            "kakao_mean": means["카카오"],
            "naver_review_count": counts["네이버"],
            "kakao_review_count": counts["카카오"],
            "naver_std": stds["네이버"],
            "kakao_std": stds["카카오"],
            "naver_median": medians["네이버"],
            "kakao_median": medians["카카오"],
        }
    ).dropna(subset=["naver_mean", "kakao_mean"])

    comparison["platform_gap"] = comparison["naver_mean"] - comparison["kakao_mean"]
    comparison["absolute_gap"] = comparison["platform_gap"].abs()
    comparison["more_positive_platform"] = np.select(
        [
            comparison["platform_gap"] > 0,
            comparison["platform_gap"] < 0,
        ],
        ["네이버", "카카오"],
        default="동일",
    )
    comparison["eligible_min_reviews"] = (
        (comparison["naver_review_count"] >= MIN_REVIEWS_PER_PLATFORM)
        & (comparison["kakao_review_count"] >= MIN_REVIEWS_PER_PLATFORM)
    )
    return comparison.sort_values("absolute_gap", ascending=False).reset_index(drop=True)


def build_paired_gap_summary(comparison):
    """동일 식당의 플랫폼 차이를 식당 단위로 요약하고 bootstrap CI를 계산합니다."""
    eligible = comparison.loc[comparison["eligible_min_reviews"]].copy()
    if eligible.empty:
        eligible = comparison.copy()

    gaps = eligible["platform_gap"].to_numpy(dtype=float)
    rng = np.random.default_rng(20260615)
    bootstrap_means = np.array(
        [
            rng.choice(gaps, size=len(gaps), replace=True).mean()
            for _ in range(20000)
        ]
    )
    ci_low, ci_high = np.quantile(bootstrap_means, [0.025, 0.975])
    return pd.DataFrame(
        [
            {
                "min_reviews_per_platform": MIN_REVIEWS_PER_PLATFORM,
                "common_store_count": len(eligible),
                "paired_mean_gap_naver_minus_kakao": gaps.mean(),
                "paired_median_gap_naver_minus_kakao": np.median(gaps),
                "paired_gap_std": sample_std(pd.Series(gaps)),
                "bootstrap_ci95_low": ci_low,
                "bootstrap_ci95_high": ci_high,
                "naver_higher_store_count": int((gaps > 0).sum()),
                "kakao_higher_store_count": int((gaps < 0).sum()),
                "equal_store_count": int((gaps == 0).sum()),
            }
        ]
    )


def build_aspect_summary(df, common_store_names):
    """동일 식당 구성 차이를 통제하기 위해 양쪽 플랫폼 공통 식당만 사용합니다."""
    available = [column for column in ASPECT_COLUMNS if column in df.columns]
    if not available:
        return pd.DataFrame()

    common_df = df.loc[df["store_name"].isin(common_store_names)].copy()
    platform_means = common_df.groupby("platform")[available].mean().T
    platform_means.index = [column.removesuffix("_score") for column in platform_means.index]
    platform_means.index.name = "aspect"
    platform_means = platform_means.reset_index()
    platform_means.insert(0, "scope", "공통 식당·플랫폼별 리뷰 5개 이상")
    platform_means["naver_minus_kakao"] = (
        platform_means["네이버"] - platform_means["카카오"]
    )
    return platform_means


def save_platform_average_figure(summary):
    order = ["네이버", "카카오"]
    plot_df = summary.set_index("platform").loc[order].reset_index()

    fig, ax = plt.subplots(figsize=(8.5, 5.5))
    bars = ax.bar(
        plot_df["platform"],
        plot_df["sentiment_star_mean"],
        color=[PLATFORM_COLORS[x] for x in plot_df["platform"]],
        width=0.55,
        edgecolor="#333333",
        linewidth=0.8,
        yerr=1.96 * plot_df["standard_error"],
        capsize=7,
    )
    ax.set_title("플랫폼별 평균 감성 별점 비교", fontsize=17, fontweight="bold", pad=16)
    ax.set_ylabel("평균 감성 별점")
    ax.set_ylim(0, 5.35)
    ax.grid(axis="y", linestyle="--", alpha=0.28)

    for bar, mean, count in zip(
        bars, plot_df["sentiment_star_mean"], plot_df["review_count"]
    ):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.12,
            f"{mean:.3f}점\n(n={count:,})",
            ha="center",
            va="bottom",
            fontsize=11,
            fontweight="bold",
        )

    gap = (
        plot_df.loc[plot_df["platform"] == "네이버", "sentiment_star_mean"].iloc[0]
        - plot_df.loc[plot_df["platform"] == "카카오", "sentiment_star_mean"].iloc[0]
    )
    ax.text(
        0.5,
        0.07,
        f"평균 차이: 네이버 - 카카오 = {gap:+.3f}점",
        transform=ax.transAxes,
        ha="center",
        bbox={"boxstyle": "round,pad=0.45", "fc": "#F5F5F5", "ec": "#AAAAAA"},
    )
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "fig_platform_avg_sentiment_star.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def save_store_dumbbell_figure(comparison):
    eligible = comparison.loc[comparison["eligible_min_reviews"]].copy()
    if eligible.empty:
        eligible = comparison.copy()
        subtitle = "양쪽 플랫폼 리뷰 보유 식당"
    else:
        subtitle = f"플랫폼별 리뷰 {MIN_REVIEWS_PER_PLATFORM}개 이상 식당"

    plot_df = (
        eligible.nlargest(TOP_N_GAP_STORES, "absolute_gap")
        .sort_values("platform_gap")
        .reset_index(drop=True)
    )
    y = np.arange(len(plot_df))

    fig_height = max(7, 0.48 * len(plot_df) + 2.7)
    fig, ax = plt.subplots(figsize=(11, fig_height))
    for idx, row in plot_df.iterrows():
        ax.plot(
            [row["naver_mean"], row["kakao_mean"]],
            [idx, idx],
            color="#B7B7B7",
            linewidth=2.2,
            zorder=1,
        )

    ax.scatter(
        plot_df["naver_mean"],
        y,
        s=75,
        color=PLATFORM_COLORS["네이버"],
        edgecolor="#333333",
        linewidth=0.5,
        label="네이버 평균",
        zorder=3,
    )
    ax.scatter(
        plot_df["kakao_mean"],
        y,
        s=75,
        color=PLATFORM_COLORS["카카오"],
        edgecolor="#333333",
        linewidth=0.5,
        label="카카오 평균",
        zorder=3,
    )

    for idx, row in plot_df.iterrows():
        right = max(row["naver_mean"], row["kakao_mean"])
        ax.text(
            min(5.07, right + 0.08),
            idx,
            f"차이 {row['platform_gap']:+.2f}",
            va="center",
            fontsize=8.5,
        )

    ax.set_yticks(y)
    ax.set_yticklabels(plot_df["store_name"])
    ax.set_xlim(1, 5.35)
    ax.set_xlabel("평균 감성 별점")
    ax.set_title(
        "같은 식당의 네이버·카카오 감성 별점 차이",
        fontsize=17,
        fontweight="bold",
        pad=20,
    )
    ax.text(
        0,
        1.015,
        f"절대 차이가 큰 상위 {len(plot_df)}개 식당 · {subtitle}",
        transform=ax.transAxes,
        fontsize=10,
        color="#555555",
    )
    ax.grid(axis="x", linestyle="--", alpha=0.28)
    ax.legend(loc="upper left", frameon=True)
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "fig_store_naver_kakao_sentiment_comparison.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def save_store_gap_figure(comparison):
    eligible = comparison.loc[comparison["eligible_min_reviews"]].copy()
    if eligible.empty:
        eligible = comparison.copy()
    plot_df = eligible.sort_values("platform_gap").reset_index(drop=True)
    colors = np.where(plot_df["platform_gap"] >= 0, "#2DB400", "#F5B400")

    fig_height = max(8, 0.32 * len(plot_df) + 2.8)
    fig, ax = plt.subplots(figsize=(11, fig_height))
    y = np.arange(len(plot_df))
    ax.barh(y, plot_df["platform_gap"], color=colors, edgecolor="none")
    ax.axvline(0, color="#333333", linewidth=1)
    ax.set_yticks(y)
    ax.set_yticklabels(plot_df["store_name"], fontsize=8.5)
    ax.set_xlabel("플랫폼 차이 (네이버 평균 - 카카오 평균)")
    ax.set_title(
        "식당별 플랫폼 감성 차이: 네이버 평균 - 카카오 평균",
        fontsize=16,
        fontweight="bold",
        pad=16,
    )
    ax.grid(axis="x", linestyle="--", alpha=0.25)
    ax.text(
        0.01,
        1.01,
        f"초록색: 네이버가 더 긍정적 · 노란색: 카카오가 더 긍정적 · 플랫폼별 리뷰 {MIN_REVIEWS_PER_PLATFORM}개 이상",
        transform=ax.transAxes,
        fontsize=9.5,
        color="#555555",
    )
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "fig_store_platform_gap.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def save_aspect_heatmap(aspect_summary):
    if aspect_summary.empty:
        return

    columns = ["네이버", "카카오", "naver_minus_kakao"]
    matrix = aspect_summary.set_index("aspect")[columns]
    max_abs = max(0.25, float(np.nanmax(np.abs(matrix.values))))
    norm = TwoSlopeNorm(vmin=-max_abs, vcenter=0, vmax=max_abs)

    fig, ax = plt.subplots(figsize=(9.5, 6.4))
    image = ax.imshow(matrix.values, cmap="RdYlGn", norm=norm, aspect="auto")
    ax.set_xticks(np.arange(3))
    ax.set_xticklabels(["네이버 평균", "카카오 평균", "차이\n(네이버-카카오)"])
    ax.set_yticks(np.arange(len(matrix.index)))
    ax.set_yticklabels(matrix.index)
    ax.set_title(
        "동일 식당 기준 플랫폼별 카테고리 감성 차이",
        fontsize=17,
        fontweight="bold",
        pad=16,
    )

    for row in range(matrix.shape[0]):
        for column in range(matrix.shape[1]):
            value = matrix.iloc[row, column]
            ax.text(
                column,
                row,
                f"{value:+.3f}",
                ha="center",
                va="center",
                fontsize=10,
                color="#111111",
                fontweight="bold" if column == 2 else "normal",
            )

    colorbar = fig.colorbar(image, ax=ax, shrink=0.82)
    colorbar.set_label("평균 aspect 점수")
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "fig_aspect_platform_heatmap.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


def build_interpretation(platform_summary, comparison, paired_gap_summary):
    summary = platform_summary.set_index("platform")
    naver_mean = float(summary.loc["네이버", "sentiment_star_mean"])
    kakao_mean = float(summary.loc["카카오", "sentiment_star_mean"])
    overall_gap = naver_mean - kakao_mean

    eligible = comparison.loc[comparison["eligible_min_reviews"]].copy()
    if eligible.empty:
        eligible = comparison.copy()
    paired_mean_gap = float(
        paired_gap_summary.loc[0, "paired_mean_gap_naver_minus_kakao"]
    )
    paired_ci_low = float(paired_gap_summary.loc[0, "bootstrap_ci95_low"])
    paired_ci_high = float(paired_gap_summary.loc[0, "bootstrap_ci95_high"])
    naver_higher = int((eligible["platform_gap"] > 0).sum())
    kakao_higher = int((eligible["platform_gap"] < 0).sum())
    top_three = eligible.nlargest(3, "absolute_gap")

    examples = ", ".join(
        f"{row.store_name}({row.more_positive_platform}가 {row.absolute_gap:.2f}점 높음)"
        for row in top_three.itertuples()
    )
    overall_more_positive = "네이버" if overall_gap > 0 else "카카오"
    paired_more_positive = "네이버" if paired_mean_gap > 0 else "카카오"

    lines = [
        (
            f"네이버 리뷰의 평균 감성 별점은 {naver_mean:.3f}점, 카카오 리뷰는 "
            f"{kakao_mean:.3f}점으로, 전체 리뷰 기준 {overall_more_positive}가 "
            f"{abs(overall_gap):.3f}점 더 긍정적으로 나타났다."
        ),
        (
            f"같은 식당을 비교하기 위해 양쪽 플랫폼에서 각각 {MIN_REVIEWS_PER_PLATFORM}개 "
            f"이상의 리뷰가 있는 {len(eligible)}개 식당을 분석한 결과, 식당별 평균 차이도 "
            f"{paired_more_positive} 방향으로 {abs(paired_mean_gap):.3f}점 나타났다"
            f"(bootstrap 95% 구간: {paired_ci_low:+.3f}~{paired_ci_high:+.3f})."
        ),
        (
            f"해당 식당 중 네이버 평균이 더 높은 식당은 {naver_higher}개, 카카오 평균이 "
            f"더 높은 식당은 {kakao_higher}개였다."
        ),
        f"플랫폼 차이가 큰 식당 예시는 {examples}이다.",
        (
            "따라서 동일한 식당이라도 플랫폼에 따라 리뷰의 감성 별점과 평가 양상이 "
            "다르게 나타나는 경향을 확인할 수 있다. 다만 이는 기술통계 결과이므로, "
            "플랫폼 이용자 구성이나 리뷰 수 차이가 원인이라고 단정할 수는 없다."
        ),
    ]
    return lines


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"입력 CSV를 찾을 수 없습니다: {INPUT_FILE}")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    selected_font = configure_korean_font()
    df, encoding = read_csv_safely(INPUT_FILE)

    required_columns = {"platform", "store_name", "review_text", "sentiment_star"}
    missing = sorted(required_columns - set(df.columns))
    if missing:
        raise ValueError(f"필수 컬럼이 없습니다: {missing}")

    df = df.copy()
    df["platform"] = df["platform"].apply(normalize_platform)
    df["store_name"] = df["store_name"].fillna("").astype(str).str.strip()
    df["sentiment_star"] = pd.to_numeric(df["sentiment_star"], errors="coerce")

    numeric_columns = ["rating", "diff", "diff_abs"] + [
        column for column in ASPECT_COLUMNS if column in df.columns
    ]
    for column in numeric_columns:
        if column in df.columns:
            df[column] = pd.to_numeric(df[column], errors="coerce")

    df = df.loc[
        df["platform"].isin(["네이버", "카카오"])
        & df["sentiment_star"].notna()
        & df["store_name"].ne("")
    ].copy()

    platform_summary = build_platform_summary(df)
    store_comparison = build_store_comparison(df)
    store_comparison_filtered = store_comparison.loc[
        store_comparison["eligible_min_reviews"]
    ].copy()
    paired_gap_summary = build_paired_gap_summary(store_comparison)
    common_store_names = set(store_comparison_filtered["store_name"])
    if not common_store_names:
        common_store_names = set(store_comparison["store_name"])
    aspect_summary = build_aspect_summary(df, common_store_names)

    platform_summary.to_csv(
        OUTPUT_DIR / "platform_sentiment_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    store_comparison.to_csv(
        OUTPUT_DIR / "store_naver_kakao_sentiment_comparison.csv",
        index=False,
        encoding="utf-8-sig",
    )
    store_comparison_filtered.to_csv(
        OUTPUT_DIR / "store_naver_kakao_sentiment_comparison_min_reviews.csv",
        index=False,
        encoding="utf-8-sig",
    )
    paired_gap_summary.to_csv(
        OUTPUT_DIR / "paired_store_gap_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    if not aspect_summary.empty:
        aspect_summary.to_csv(
            OUTPUT_DIR / "aspect_platform_summary.csv",
            index=False,
            encoding="utf-8-sig",
        )

    save_platform_average_figure(platform_summary)
    save_store_dumbbell_figure(store_comparison)
    save_store_gap_figure(store_comparison)
    save_aspect_heatmap(aspect_summary)

    interpretation = build_interpretation(
        platform_summary,
        store_comparison,
        paired_gap_summary,
    )
    (OUTPUT_DIR / "presentation_interpretation.txt").write_text(
        "\n\n".join(interpretation) + "\n",
        encoding="utf-8",
    )

    print(f"[입력 인코딩] {encoding}")
    print(f"[한글 폰트] {selected_font}")
    print(f"[분석 리뷰 수] {len(df):,}")
    print(f"[양쪽 플랫폼 공통 식당 수] {len(store_comparison):,}")
    print(
        f"[플랫폼별 최소 {MIN_REVIEWS_PER_PLATFORM}개 리뷰 공통 식당 수] "
        f"{len(store_comparison_filtered):,}"
    )
    print("\n[플랫폼별 요약]")
    print(platform_summary.to_string(index=False))
    print("\n[발표용 해석]")
    for line in interpretation:
        print(f"- {line}")
    print(f"\n[산출물 폴더] {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
