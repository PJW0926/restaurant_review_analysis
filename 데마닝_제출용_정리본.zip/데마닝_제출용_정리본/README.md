# 데이터마이닝 프로젝트 코드 실행 안내

## 1. 프로젝트 개요

본 프로젝트는 네이버와 카카오 음식점 리뷰를 대상으로 플랫폼별 리뷰 생성 특성을 고려하여 리뷰 신뢰도를 산출하고, High Trust 리뷰를 기반으로 감성별점을 계산하는 분석 파이프라인입니다.

전체 흐름은 다음과 같습니다.

1. 수동 라벨링 데이터로 trust score 기반 신뢰도 필터의 성능을 평가합니다.
2. 전체 크롤링 리뷰에 동일한 trust score 규칙을 적용하여 `low`, `ambiguous`, `high` trust 리뷰를 구분합니다.
3. High Trust 리뷰를 대상으로 음식점 리뷰 도메인 감성사전과 문맥 보정 규칙을 적용하여 `sentiment_star`를 산출합니다.
4. 플랫폼별·식당별·aspect별 시각화를 생성합니다.

## 2. 폴더 구조

```text
.
├── README.md
├── requirements.txt
├── code/
│   ├── 01_label_analysis_all_labeled.py
│   ├── 02_label_analysis_all_crawling.py
│   ├── 03_sentiment_analysis.py
│   ├── 04_platform_avg_only_with_summary_box.py
│   └── 05_platform_sentiment_dumbbell_only_clean_v2.py
├── data/
│   ├── all_크롤링.csv
│   ├── all_크롤링_pos.csv
│   ├── final_high_trust_reviews_pos.csv
│   ├── 통합_감성사전_v10.csv
│   ├── 통합_감성사전_v9.csv
│   └── README_missing_labeled_data.md
├── outputs/
│   ├── final_high_trust_reviews_sentiment_star_positive_recovery_review_view.csv
│   ├── final_high_trust_reviews_with_sentiment_star_positive_recovery.csv
│   ├── final_high_trust_reviews_with_sentiment_star_positive_recovery_compact.csv
│   ├── platform_aspect_sentiment_summary_positive_recovery.csv
│   ├── store_aspect_sentiment_summary_positive_recovery.csv
│   └── positive_recovery_sentiment_error_summary.csv
└── figures/
    └── 주요 결과 시각화 PNG 파일
```

## 3. 데이터 설명

| 파일명 | 설명 |
|---|---|
| `all_라벨링.csv` | 수동 라벨링된 신뢰도 평가 데이터입니다. 현재 제출용 폴더에는 포함되어 있지 않으므로, `01_label_analysis_all_labeled.py` 실행 시 `data/` 폴더에 추가해야 합니다. |
| `all_크롤링.csv` | 네이버·카카오에서 수집한 전체 리뷰 데이터입니다. 전체 리뷰에 trust score를 산출할 때 사용합니다. |
| `all_크롤링_pos.csv` | 형태소 분석 또는 토큰 정보가 추가된 전체 리뷰 데이터입니다. |
| `final_high_trust_reviews_pos.csv` | High Trust로 선별된 리뷰에 토큰 정보가 추가된 감성분석 입력 파일입니다. |
| `통합_감성사전_v10.csv` | 최종 음식점 리뷰 도메인 감성사전입니다. `word`, `category`, `polarity`, `score` 컬럼을 사용합니다. |
| `통합_감성사전_v9.csv` | 감성분석 코드에서 fallback으로 참조할 수 있는 이전 감성사전입니다. |
| `final_high_trust_reviews_with_sentiment_star_positive_recovery.csv` | High Trust 리뷰에 감성분석 결과와 감성별점이 추가된 최종 산출물입니다. |
| `final_high_trust_reviews_sentiment_star_positive_recovery_review_view.csv` | 발표 및 시각화에 사용하기 좋게 정리한 감성별점 결과 파일입니다. |

## 4. 주요 코드 설명

### 4.1 `01_label_analysis_all_labeled.py`

수동 라벨링 데이터의 `manual_label`과 trust score 기반 `pred_label`을 비교하여 신뢰도 필터의 성능을 평가합니다.

주요 출력:
- Accuracy, Precision, Recall, F1-score
- Confusion Matrix
- threshold별 성능 비교표
- 오분류 사례 파일

주의:
- 이 코드를 실행하려면 `data/all_라벨링.csv`가 필요합니다.
- 현재 업로드된 ZIP에서는 해당 파일을 찾지 못했기 때문에, 별도로 추가해야 합니다.

### 4.2 `02_label_analysis_all_crawling.py`

전체 크롤링 리뷰에 규칙 기반 trust score를 적용합니다. 수동 라벨은 사용하지 않고, 리뷰별로 `trust_score`, `trust_level`, `trust_weight`, `trust_reasons`를 산출합니다.

주요 기준:
- `LOW_TRUST_THRESHOLD = 0.5`
- `HIGH_TRUST_THRESHOLD = 3.5`
- trust score가 3.5 이상이면 High Trust 리뷰로 분류합니다.

주요 출력:
- `crawling_all_filter_result.csv`
- `final_high_trust_reviews.csv`
- `platform_trust_summary.csv`
- `store_trust_summary.csv`

### 4.3 `03_sentiment_analysis.py`

High Trust 리뷰를 대상으로 감성사전 기반 감성분석을 수행합니다. 단순 사전 매칭이 아니라 phrase rule, context guard, 중복 제거, aspect별 가중치, 감성별점 변환을 포함합니다.

입력:
- `data/final_high_trust_reviews_pos.csv`
- `data/통합_감성사전_v10.csv`

주요 출력:
- `outputs/sentiment/final_high_trust_reviews_with_sentiment_star_positive_recovery.csv`
- `outputs/sentiment/final_high_trust_reviews_sentiment_star_positive_recovery_review_view.csv`
- `outputs/sentiment/platform_aspect_sentiment_summary_positive_recovery.csv`
- `outputs/sentiment/store_aspect_sentiment_summary_positive_recovery.csv`
- `outputs/sentiment/positive_recovery_sentiment_error_summary.csv`

감성별점 계산식:

```text
Sentiment Star = clip(3.0 + 0.34 × Weighted Score, 1, 5)
```

### 4.4 `04_platform_avg_only_with_summary_box.py`

High Trust 리뷰의 플랫폼별 평균 감성별점을 막대그래프로 시각화합니다.

출력:
- `figures/fig_platform_avg_sentiment_star.png`

### 4.5 `05_platform_sentiment_dumbbell_only_clean_v2.py`

네이버와 카카오에 모두 존재하는 식당을 기준으로 플랫폼별 감성별점 차이를 dumbbell chart로 시각화합니다.

출력:
- `figures/fig_store_naver_kakao_sentiment_comparison.png`

## 5. 실행 환경 및 요구 패키지

권장 환경:
- Python 3.10 이상
- Windows 환경에서는 `Malgun Gothic` 폰트 사용 권장

설치 명령어:

```bash
pip install -r requirements.txt
```

주요 패키지:
- `pandas`: CSV 데이터 처리
- `numpy`: 수치 연산
- `scikit-learn`: 성능 평가 지표 및 보조 모델 비교
- `matplotlib`: 시각화 생성
- `openpyxl`: Excel 파일 읽기 지원
- `konlpy`: 형태소 분석 관련 코드 실행 시 필요
- `tqdm`: 진행률 표시가 필요한 일부 코드에서 사용 가능

## 6. 실행 방법

프로젝트 루트 폴더에서 아래 순서로 실행합니다.

### 6.1 수동 라벨 기반 신뢰도 필터 성능 평가

```bash
python code/01_label_analysis_all_labeled.py
```

주의: 이 단계는 `data/all_라벨링.csv`가 있을 때만 실행 가능합니다.

### 6.2 전체 크롤링 리뷰 trust score 산출

```bash
python code/02_label_analysis_all_crawling.py
```

### 6.3 High Trust 리뷰 감성분석 및 감성별점 산출

```bash
python code/03_sentiment_analysis.py
```

### 6.4 최종 시각화 생성

```bash
python code/04_platform_avg_only_with_summary_box.py
python code/05_platform_sentiment_dumbbell_only_clean_v2.py
```

## 7. 재현 관련 주의사항

1. `01_label_analysis_all_labeled.py`는 수동 라벨 파일인 `all_라벨링.csv`가 있어야 실행됩니다.
2. `02_label_analysis_all_crawling.py`는 전체 크롤링 데이터에 trust score를 적용하는 코드이며, 수동 라벨을 사용하지 않습니다.
3. `03_sentiment_analysis.py`는 이미 High Trust로 선별되고 토큰 정보가 포함된 `final_high_trust_reviews_pos.csv`를 입력으로 사용합니다.
4. 본 제출용 폴더의 Python 파일은 교수님이 상대경로로 실행할 수 있도록 기존 절대경로를 프로젝트 폴더 기준 상대경로로 조정한 버전입니다.
5. 중간 실험 파일과 과거 버전 결과물은 제출 폴더에서 제외하고, 최종 재현에 필요한 파일 중심으로 구성했습니다.

## 8. 주요 결과 파일 확인 위치

| 목적 | 파일 위치 |
|---|---|
| 신뢰도 필터 적용 결과 | `outputs/trust_crawling/` |
| 감성별점 산출 결과 | `outputs/sentiment/` 또는 `outputs/` |
| 최종 시각화 | `figures/` |
| 감성분석 오류 요약 | `outputs/positive_recovery_sentiment_error_summary.csv` |

## 9. 문의/검토 포인트

- 수동 라벨링 성능 평가까지 완전히 재현하려면 `data/all_라벨링.csv`를 추가해야 합니다.
- 감성분석 결과는 `통합_감성사전_v10.csv`와 `03_sentiment_analysis.py`의 문맥 보정 규칙을 기준으로 산출됩니다.
- 최종 보고서의 threshold 설명에서는 `5.7`은 수동 라벨 기반 binary 평가 기준, `3.5`는 최종 High Trust 운영 기준으로 구분합니다.
