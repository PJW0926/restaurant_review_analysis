# 수동 라벨링 데이터 안내

현재 업로드된 ZIP 안에서는 `all_라벨링.csv` 파일을 찾지 못했습니다.

`code/01_label_analysis_all_labeled.py`를 실행하려면 이 폴더(`data/`) 안에 수동 라벨링 파일을 아래 이름으로 추가해야 합니다.

- `all_라벨링.csv`

필수 컬럼 예시:
- `review_text`: 리뷰 본문
- `manual_label`: 수동 라벨. 코드 기준 0=fake/저신뢰, 1=real/실제 경험 리뷰
- 선택 컬럼: `platform`, `store_name`, `account_review_count`, `has_photo`, `rating`, `account_avg_rating`, `visit_count`
